import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { requireAuth, AuthRequest } from './src/middleware/auth.ts';
import { getOrCreateUser } from './src/db/users.ts';
import { getUserMemories, saveUserMemory, clearUserMemories } from './src/db/memories.ts';
import { getUserVitals, saveUserVitals } from './src/db/vitals.ts';
import { routeIntent } from './src/services/ai/intentRouter.ts';
import { conductWebResearch } from './src/services/ai/webResearchService.ts';
import { fetchLatestNews } from './src/services/ai/newsService.ts';
import { planAndInitTask, executeNextTaskStep, pauseTask, resumeTask } from './src/services/ai/taskEngine.ts';
import { getUserTasks } from './src/db/tasks.ts';
import { createNote, getUserNotes, updateNote, deleteNote } from './src/db/notes.ts';
import { getUserResearches } from './src/db/researches.ts';
import { getUserWorkflows } from './src/db/workflows.ts';
import { createReminder, getUserReminders, updateReminderStatus } from './src/db/reminders.ts';
import { preparePhoneCall, prepareWhatsAppMessage, getDeviceCapabilities } from './src/services/ai/deviceIntegrationService.ts';
import { ai, generateContentWithFallback } from './src/services/ai/geminiClient.ts';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ 
      status: 'ok', 
      system: 'EZUMI Personal AI Companion', 
      version: '2.0.0', 
      timestamp: new Date().toISOString() 
    });
  });

  // Authenticated user sync route
  app.post('/api/auth/sync', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user?.uid;
      const email = req.user?.email || 'anonymous@user.com';
      const name = (req.user as any)?.name || null;

      if (!uid) {
        return res.status(401).json({ error: 'Unauthorized' });
      }

      const user = await getOrCreateUser(uid, email, name);
      res.json({ status: 'ok', user });
    } catch (error: any) {
      console.error('Failed to sync user:', error);
      res.status(500).json({ error: error.message || 'Failed to sync user' });
    }
  });

  // Get user memories from Cloud SQL
  app.get('/api/memories', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user?.uid;
      if (!uid) return res.status(401).json({ error: 'Unauthorized' });

      const email = req.user?.email || 'user@app.local';
      await getOrCreateUser(uid, email);

      const records = await getUserMemories(uid);
      res.json({ memories: records });
    } catch (error: any) {
      console.error('Failed to load memories:', error);
      res.status(500).json({ error: error.message || 'Failed to fetch memories' });
    }
  });

  // Save a memory turn to Cloud SQL
  app.post('/api/memories', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user?.uid;
      if (!uid) return res.status(401).json({ error: 'Unauthorized' });

      const { role, text } = req.body;
      if (!role || !text) {
        return res.status(400).json({ error: 'Missing role or text' });
      }

      const email = req.user?.email || 'user@app.local';
      await getOrCreateUser(uid, email);

      const saved = await saveUserMemory(uid, role, text);
      res.json({ status: 'ok', memory: saved });
    } catch (error: any) {
      console.error('Failed to save memory:', error);
      res.status(500).json({ error: error.message || 'Failed to save memory' });
    }
  });

  // Clear user memories
  app.delete('/api/memories', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user?.uid;
      if (!uid) return res.status(401).json({ error: 'Unauthorized' });

      await clearUserMemories(uid);
      res.json({ status: 'ok' });
    } catch (error: any) {
      console.error('Failed to clear memories:', error);
      res.status(500).json({ error: error.message || 'Failed to clear memories' });
    }
  });

  // Get vitals
  app.get('/api/vitals', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user?.uid;
      if (!uid) return res.status(401).json({ error: 'Unauthorized' });

      const vitals = await getUserVitals(uid);
      res.json({ vitals });
    } catch (error: any) {
      console.error('Failed to fetch vitals:', error);
      res.status(500).json({ error: error.message || 'Failed to fetch vitals' });
    }
  });

  // Save vitals
  app.post('/api/vitals', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user?.uid;
      if (!uid) return res.status(401).json({ error: 'Unauthorized' });

      const { hydration, hunger, mood } = req.body;
      const email = req.user?.email || 'user@app.local';
      await getOrCreateUser(uid, email);

      const saved = await saveUserVitals(uid, {
        hydration: Number(hydration ?? 85),
        hunger: Number(hunger ?? 20),
        mood: Number(mood ?? 100),
      });

      res.json({ status: 'ok', vitals: saved });
    } catch (error: any) {
      console.error('Failed to save vitals:', error);
      res.status(500).json({ error: error.message || 'Failed to save vitals' });
    }
  });

  // ==========================================
  // CENTRAL AI ORCHESTRATION LAYER ENDPOINTS
  // ==========================================

  // 1. Natural Language Intent Routing
  app.post('/api/ai/intent', async (req, res) => {
    try {
      const { text } = req.body;
      if (!text) return res.status(400).json({ error: 'Text prompt required' });
      const intent = await routeIntent(text);
      res.json(intent);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 2. Real Web Research with Grounded Search Citations
  app.post('/api/ai/research', async (req: AuthRequest, res) => {
    try {
      const { query, topic } = req.body;
      const uid = req.user?.uid || '';
      if (!query) return res.status(400).json({ error: 'Query is required' });

      const research = await conductWebResearch(uid, query, topic);
      res.json(research);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/ai/research/history', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user?.uid;
      if (!uid) return res.status(401).json({ error: 'Unauthorized' });
      const history = await getUserResearches(uid);
      res.json({ history });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 3. Live News Intelligence & Audio Reading
  app.get('/api/ai/news', async (req, res) => {
    try {
      const category = (req.query.category as string) || 'Technology & Artificial Intelligence';
      const news = await fetchLatestNews(category);
      res.json(news);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 4. Conversational Chat & Reasoning (Fallback or Text interface)
  app.post('/api/ai/chat', async (req: AuthRequest, res) => {
    try {
      const { message, history, persona, temperature } = req.body;
      if (!message) return res.status(400).json({ error: 'Message required' });

      const systemInstruction = persona || `You are EZUMI, an advanced personal AI companion built for Android tablet and desktop hands-free interaction.
You behave like a seamless combination of ChatGPT and Alexa.
You are warm, intelligent, attentive, clear, and deeply capable.
You speak naturally in expressive English or Hinglish depending on how the user addresses you.
Provide helpful, well-structured, formatted responses with clarity and empathy. Keep spoken or voice-activated answers conversational and succinct, while providing complete, rich detail when asked for explanations or instructions.`;

      const validHistory = (history || [])
        .filter((h: any) => h && h.text && (h.role === 'user' || h.role === 'assistant' || h.role === 'model'))
        .map((h: any) => ({
          role: h.role === 'assistant' ? 'model' : h.role,
          parts: [{ text: h.text }]
        }));

      const contents = [
        ...validHistory,
        { role: 'user', parts: [{ text: message }] }
      ];

      const response = await generateContentWithFallback({
        primaryModel: 'gemini-2.5-flash',
        contents,
        config: {
          systemInstruction,
          temperature: typeof temperature === 'number' ? temperature : 0.7,
        }
      });

      res.json({ reply: response.text || "Main aapki baat samajh gayi hoon." });
    } catch (err: any) {
      console.error('Chat endpoint error:', err);
      res.status(500).json({ error: err.message || 'Chat processing error' });
    }
  });

  // 5. Autonomous Tasks Engine
  app.get('/api/tasks', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user?.uid;
      if (!uid) return res.status(401).json({ error: 'Unauthorized' });
      const tasksList = await getUserTasks(uid);
      res.json({ tasks: tasksList });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/tasks', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user?.uid;
      if (!uid) return res.status(401).json({ error: 'Unauthorized' });
      const { goal } = req.body;
      if (!goal) return res.status(400).json({ error: 'Task goal is required' });

      const task = await planAndInitTask(uid, goal);
      res.json({ status: 'ok', task });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/tasks/:id/step', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user?.uid;
      const taskId = Number(req.params.id);
      if (!uid) return res.status(401).json({ error: 'Unauthorized' });

      const task = await executeNextTaskStep(uid, taskId);
      res.json({ status: 'ok', task });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/tasks/:id/status', requireAuth, async (req: AuthRequest, res) => {
    try {
      const taskId = Number(req.params.id);
      const { action } = req.body; // 'pause' | 'resume'
      const updated = action === 'pause' ? await pauseTask(taskId) : await resumeTask(taskId);
      res.json({ status: 'ok', task: updated });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 6. Smart Voice Notepad
  app.get('/api/notes', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user?.uid;
      if (!uid) return res.status(401).json({ error: 'Unauthorized' });
      const notesList = await getUserNotes(uid);
      res.json({ notes: notesList });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/notes', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user?.uid;
      if (!uid) return res.status(401).json({ error: 'Unauthorized' });
      const { title, content, tags } = req.body;
      const note = await createNote(uid, {
        title: title || `Note - ${new Date().toLocaleDateString()}`,
        content: content || '',
        tags: tags || 'voice-note',
      });
      res.json({ status: 'ok', note });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put('/api/notes/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const noteId = Number(req.params.id);
      const { content, title, tags } = req.body;
      const updated = await updateNote(noteId, content, title, tags);
      res.json({ status: 'ok', note: updated });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete('/api/notes/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const noteId = Number(req.params.id);
      await deleteNote(noteId);
      res.json({ status: 'ok' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 7. Workflow Learning System
  app.get('/api/workflows', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user?.uid;
      if (!uid) return res.status(401).json({ error: 'Unauthorized' });
      const workflowsList = await getUserWorkflows(uid);
      res.json({ workflows: workflowsList });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 8. Reminders & Proactive Alerts
  app.get('/api/reminders', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user?.uid;
      if (!uid) return res.status(401).json({ error: 'Unauthorized' });
      const rems = await getUserReminders(uid);
      res.json({ reminders: rems });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/reminders', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user?.uid;
      if (!uid) return res.status(401).json({ error: 'Unauthorized' });
      const { title, dueAt, priority, repeat } = req.body;
      const reminder = await createReminder(uid, {
        title,
        dueAt: new Date(dueAt || Date.now() + 3600000),
        priority,
        repeat,
      });
      res.json({ status: 'ok', reminder });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.patch('/api/reminders/:id/status', requireAuth, async (req: AuthRequest, res) => {
    try {
      const remId = Number(req.params.id);
      const { status } = req.body;
      const updated = await updateReminderStatus(remId, status);
      res.json({ status: 'ok', reminder: updated });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 9. Device Integrations: Calling & Messaging
  app.post('/api/device/call', async (req: AuthRequest, res) => {
    try {
      const uid = req.user?.uid || 'guest';
      const { contactName, phoneNumber } = req.body;
      const intent = await preparePhoneCall(uid, contactName, phoneNumber);
      res.json(intent);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/device/whatsapp', async (req: AuthRequest, res) => {
    try {
      const uid = req.user?.uid || 'guest';
      const { contactName, phoneNumber, messageText } = req.body;
      const draft = await prepareWhatsAppMessage(uid, contactName, phoneNumber, messageText);
      res.json(draft);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/device/capabilities', (req, res) => {
    res.json(getDeviceCapabilities());
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
