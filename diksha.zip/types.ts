
export interface TranscriptionTurn {
  role: 'user' | 'assistant';
  text: string;
  timestamp: Date;
}

export enum AppStatus {
  IDLE = 'idle',
  CONNECTING = 'connecting',
  LISTENING = 'listening',
  ERROR = 'error'
}

export type VoiceSessionState =
  | 'IDLE'
  | 'REQUESTING_PERMISSION'
  | 'STANDBY'
  | 'LISTENING'
  | 'PROCESSING'
  | 'SPEAKING'
  | 'ERROR'
  | 'STOPPED';

export type AssistantVisualState = 'standby' | 'listening' | 'processing' | 'speaking';

export interface SettingsConfig {
  wakeWordEnabled: boolean;
  continuousListening: boolean;
  autoSpeakResponse: boolean;
  speechRate: number;
  speechPitch: number;
  selectedVoiceURI: string;
  modelName: string;
  aiPersona: string;
  temperature: number;
  screenAwake: boolean;
  soundFeedback: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: Date;
  updatedAt: Date;
}

