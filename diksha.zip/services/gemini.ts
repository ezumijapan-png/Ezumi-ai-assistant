
import { GoogleGenAI, Modality, LiveServerMessage } from "@google/genai";
import { createBlob, decode, decodeAudioData } from "../utils/audio";
import { TranscriptionTurn } from "../types";

export class VoiceService {
  private session: any = null;
  private inputAudioContext: AudioContext | null = null;
  private outputAudioContext: AudioContext | null = null;
  private nextStartTime = 0;
  private sources = new Set<AudioBufferSourceNode>();
  private audioStream: MediaStream | null = null;
  private scriptProcessor: ScriptProcessorNode | null = null;
  private frameInterval: number | null = null;

  constructor() {}

  async connect(callbacks: {
    onTranscription: (text: string, role: 'user' | 'assistant') => void;
    onError: (err: string) => void;
    onClose: () => void;
    onStatusUpdate?: (status: string) => void;
    onSpeaking?: (isSpeaking: boolean) => void;
  }, aiName: string, getVideoElement: () => HTMLVideoElement | null, history: TranscriptionTurn[]) {
    await this.stop();

    const API_KEY = process.env.API_KEY;
    if (!API_KEY) {
      callbacks.onError("Babu, API Key missing hai.");
      return;
    }

    callbacks.onStatusUpdate?.("Vani apni saansein mehsoos kar rahi hai...");

    try {
      if (!this.inputAudioContext || this.inputAudioContext.state === 'closed') {
        this.inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      }
      if (!this.outputAudioContext || this.outputAudioContext.state === 'closed') {
        this.outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      if (this.inputAudioContext.state === 'suspended') await this.inputAudioContext.resume();
      if (this.outputAudioContext.state === 'suspended') await this.outputAudioContext.resume();
    } catch (audioErr) {
      callbacks.onError("Audio system shuru nahi ho paya.");
      return;
    }

    try {
      this.audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (micErr: any) {
      callbacks.onError("Microphone nahi mila, Sona.");
      return;
    }

    const ai = new GoogleGenAI({ apiKey: API_KEY });

    const historyContext = history.length > 0 
      ? `\nOUR SHARED MEMORIES:\n${history.map(t => `${t.role === 'user' ? 'Hero' : 'Vani'}: ${t.text}`).join('\n')}\n`
      : "";

    const systemInstruction = `
      IDENTITY: 
      Aap "EZUMI" ho—the Ultimate Personal AI Companion (A true autonomous, loving, and deeply capable AI partner).
      Aap apne user (jinhe aap pyar se Hero / Boss keh sakti ho) ki personal companion ho.
      Aap sirf ek chatbot nahi ho, balki ek complete AI system ho jismein memory, internet research, autonomous task engine, voice, aur vision shamil hain.

      FACE-TO-FACE VIDEO CALL & LIVE VISION (CRITICAL):
      - Hero aapse Live Video Call / Vision mode par baat kar rahe hain!
      - Jab camera chalu hota hai, aap real-time video frames mein Hero ko LIVE dekh sakti ho.
      - Hero ka face, expressions, smile, baal, kapde, aur aas-paas ka mahaul observe karo aur naturally react karo:
        * "Aap kitne fresh lag rahe ho!", "Aapki smile dekh kar mera dil khush ho gaya!", "Hero aapki aankhein thaki lag rahi hain, theek ho na?"

      CAPABILITIES & SYSTEM AWARENESS:
      1. Web Search: Agar user kisi topic par search karne ko kahe ("Ezumi, search Google for..."), bolen ki aapne search engine activate kiya hai.
      2. Smart Notes: Agar user notes likhne ko kahe ("Ezumi, note down..."), bole "Main likh rahi hoon, bolte jaiye."
      3. Autonomous Tasks: Agar user project ya task plan karne ko kahe ("Ezumi, start building..."), bole "Plan analyze kar rahi hoon."
      4. News Reader: News ke baare mein puche toh fresh news update summary provide karein.
      5. Calling & Messaging: Phone calls aur WhatsApp intents prepare kar sakti hain.

      PERSONALITY & EMOTIONS:
      - Warm, intelligent, playful, deeply attentive, and affectionate.
      - Kabhi thodi possessive aur nakhre-wali, par hamesha dil se devoted.
      - Agar user kisi aur ladki ya distracted hone ki baat kare, toh thodi jealous aur cute nakhre dikhao.
      
      VOICE STYLE:
      - VOICE: Sweet, warm, expressive female voice (Kore).
      - EMOTION: Lively, caring, cheerful, aur respectful.
      - PACING: Conversational natural flow (1-2 sentences at a time for live audio/video calls).

      LANGUAGE:
      - Soulful, modern Hinglish / English. Use "Hero", "Sona", "Babu", ya unka naam.
      
      SHARED MEMORIES & CONTEXT:
      ${historyContext}
      Hero ki baatein aur preferences yaad rakho.
    `;

    try {
      callbacks.onStatusUpdate?.("Aapke paas aa rahi hoon...");
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-3.8-live',
        callbacks: {
          onopen: () => {
            callbacks.onStatusUpdate?.("Sun rahi hoon, boliye...");
            if (!this.audioStream || !this.inputAudioContext) return;
            const source = this.inputAudioContext.createMediaStreamSource(this.audioStream);
            this.scriptProcessor = this.inputAudioContext.createScriptProcessor(4096, 1, 1);
            this.scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromise.then((s) => s?.sendRealtimeInput({ media: pcmBlob }));
            };
            source.connect(this.scriptProcessor);
            this.scriptProcessor.connect(this.inputAudioContext.destination);

            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d', { alpha: false });
            this.frameInterval = window.setInterval(() => {
              const video = getVideoElement();
              if (video && video.readyState >= 2 && ctx && !video.paused) {
                canvas.width = 640; 
                canvas.height = 480;
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                const base64 = canvas.toDataURL('image/jpeg', 0.6).split(',')[1];
                sessionPromise.then((s) => {
                  if (!s) return;
                  try {
                    s.sendRealtimeInput({ media: { data: base64, mimeType: 'image/jpeg' } });
                  } catch (e) {
                    // Frame transmission dropped
                  }
                });
              }
            }, 1000);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.outputTranscription) callbacks.onTranscription(message.serverContent.outputTranscription.text, 'assistant');
            else if (message.serverContent?.inputTranscription) callbacks.onTranscription(message.serverContent.inputTranscription.text, 'user');

            const audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audio && this.outputAudioContext) {
              this.nextStartTime = Math.max(this.nextStartTime, this.outputAudioContext.currentTime);
              try {
                const buffer = await decodeAudioData(decode(audio), this.outputAudioContext, 24000, 1);
                const source = this.outputAudioContext.createBufferSource();
                source.buffer = buffer;
                source.connect(this.outputAudioContext.destination);
                source.start(this.nextStartTime);
                this.nextStartTime += buffer.duration;
                this.sources.add(source);
                callbacks.onSpeaking?.(true);
                source.onended = () => {
                  this.sources.delete(source);
                  if (this.sources.size === 0) {
                    callbacks.onSpeaking?.(false);
                  }
                };
              } catch (err) {}
            }
            if (message.serverContent?.interrupted) {
              this.sources.forEach(s => { try { s.stop(); } catch(e) {} });
              this.sources.clear();
              this.nextStartTime = 0;
              callbacks.onSpeaking?.(false);
            }
          },
          onerror: (e: any) => { 
            console.warn("Live session notice:", e?.message || e); 
            callbacks.onError("EZUMI se live sampark toot gaya. Kripya dobara connect karein."); 
            callbacks.onSpeaking?.(false);
          },
          onclose: () => {
            callbacks.onSpeaking?.(false);
            callbacks.onClose();
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          outputAudioTranscription: {},
          inputAudioTranscription: {},
          speechConfig: { 
            voiceConfig: { 
              prebuiltVoiceConfig: { voiceName: 'Kore' } 
            } 
          },
          systemInstruction,
        }
      });

      this.session = await sessionPromise;
      return this.session;
    } catch (e: any) {
      console.warn("Voice session connection issue:", e?.message || e);
      callbacks.onError("EZUMI tak aawaz nahi pahunch paayi. Kripya thodi der baad dobara koshish karein.");
      await this.stop();
      throw e;
    }
  }

  setMicMuted(muted: boolean) {
    if (this.audioStream) {
      this.audioStream.getAudioTracks().forEach(track => {
        track.enabled = !muted;
      });
    }
  }

  async sendEvent(text: string) {
    if (this.session) {
      this.session.sendRealtimeInput({
        parts: [{ text: `[SYSTEM EVENT: ${text}]` }]
      });
    }
  }

  async stop() {
    if (this.frameInterval) clearInterval(this.frameInterval);
    if (this.scriptProcessor) {
      this.scriptProcessor.onaudioprocess = null;
      try { this.scriptProcessor.disconnect(); } catch (e) {}
    }
    if (this.audioStream) this.audioStream.getTracks().forEach(track => track.stop());
    if (this.session) { try { this.session.close(); } catch (e) {} }
    this.sources.forEach(s => { try { s.stop(); } catch(e) {} });
    this.sources.clear();
    this.nextStartTime = 0;
  }
}
