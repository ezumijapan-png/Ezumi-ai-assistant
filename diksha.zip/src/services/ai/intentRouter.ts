import { ai, generateContentWithFallback } from './geminiClient.ts';
import { Type } from '@google/genai';

export interface RecognizedIntent {
  intent: 'SEARCH' | 'NOTE_TAKING' | 'TASK_CREATE' | 'TASK_CONTROL' | 'READ_NEWS' | 'CALL_PHONE' | 'MESSAGE_WHATSAPP' | 'REMINDER' | 'CHAT';
  confidence: number;
  parameters: {
    query?: string;
    noteAction?: 'create' | 'append' | 'summarize' | 'read';
    noteContent?: string;
    noteTitle?: string;
    taskGoal?: string;
    taskAction?: 'pause' | 'resume' | 'cancel' | 'status';
    newsTopic?: string;
    contactName?: string;
    phoneNumber?: string;
    messageText?: string;
    reminderTitle?: string;
    reminderTime?: string;
  };
  spokenResponsePrompt?: string;
}

export const routeIntent = async (userInput: string): Promise<RecognizedIntent> => {
  try {
    const response = await generateContentWithFallback({
      primaryModel: 'gemini-2.5-flash',
      contents: `You are the Intent Recognition Router for EZUMI, an autonomous AI companion.
Analyze the user command and categorize it accurately into one of the system intents:
- SEARCH: if the user asks to search the web, google something, check latest facts/docs.
- NOTE_TAKING: if the user asks to take notes, write what they say, summarize notes, or open notes.
- TASK_CREATE: if user asks EZUMI to build, plan, execute or start a project/task.
- TASK_CONTROL: if user asks to pause, resume, or check status of an ongoing task.
- READ_NEWS: if user asks for latest news, tech news, AI developments, or read today's headlines.
- CALL_PHONE: if user asks to call someone (e.g. "call Rahul", "dial mom").
- MESSAGE_WHATSAPP: if user asks to send a WhatsApp message or text someone.
- REMINDER: if user asks to set a reminder or alert at a specific time.
- CHAT: general conversational query, personal bonding, or greeting.

User Input: "${userInput}"`,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            intent: {
              type: Type.STRING,
              description: 'One of SEARCH, NOTE_TAKING, TASK_CREATE, TASK_CONTROL, READ_NEWS, CALL_PHONE, MESSAGE_WHATSAPP, REMINDER, CHAT',
            },
            confidence: { type: Type.NUMBER },
            parameters: {
              type: Type.OBJECT,
              properties: {
                query: { type: Type.STRING },
                noteAction: { type: Type.STRING },
                noteContent: { type: Type.STRING },
                noteTitle: { type: Type.STRING },
                taskGoal: { type: Type.STRING },
                taskAction: { type: Type.STRING },
                newsTopic: { type: Type.STRING },
                contactName: { type: Type.STRING },
                phoneNumber: { type: Type.STRING },
                messageText: { type: Type.STRING },
                reminderTitle: { type: Type.STRING },
                reminderTime: { type: Type.STRING },
              },
            },
            spokenResponsePrompt: {
              type: Type.STRING,
              description: 'A brief, natural acknowledgment in Hinglish or English to speak back to the user',
            },
          },
          required: ['intent', 'confidence', 'parameters'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return {
      intent: (parsed.intent as any) || 'CHAT',
      confidence: parsed.confidence || 0.8,
      parameters: parsed.parameters || {},
      spokenResponsePrompt: parsed.spokenResponsePrompt || 'Ji, main samajh gayi.',
    };
  } catch (error: any) {
    console.warn('Intent routing fallback activated:', error?.message || error);
    // Simple heuristic fallback
    const lower = userInput.toLowerCase();
    if (lower.includes('search') || lower.includes('google') || lower.includes('dhundo') || lower.includes('find')) {
      return {
        intent: 'SEARCH',
        confidence: 0.7,
        parameters: { query: userInput.replace(/search|google|dhundo|ezumi/gi, '').trim() },
        spokenResponsePrompt: 'Main internet par search kar rahi hoon...',
      };
    }
    if (lower.includes('note') || lower.includes('likho') || lower.includes('write')) {
      return {
        intent: 'NOTE_TAKING',
        confidence: 0.7,
        parameters: { noteAction: 'append', noteContent: userInput },
        spokenResponsePrompt: 'Main note likh rahi hoon...',
      };
    }
    if (lower.includes('news') || lower.includes('samachar') || lower.includes('khabar')) {
      return {
        intent: 'READ_NEWS',
        confidence: 0.7,
        parameters: { newsTopic: 'top headlines' },
        spokenResponsePrompt: 'Aaj ki taza khabrein laa rahi hoon...',
      };
    }
    if (lower.includes('call') || lower.includes('phone')) {
      return {
        intent: 'CALL_PHONE',
        confidence: 0.7,
        parameters: { contactName: userInput.replace(/call|phone|ezumi/gi, '').trim() },
        spokenResponsePrompt: 'Call prepare kar rahi hoon...',
      };
    }
    return {
      intent: 'CHAT',
      confidence: 0.9,
      parameters: {},
      spokenResponsePrompt: 'Bataiye, main aapke saath hoon.',
    };
  }
};
