import { GoogleGenAI } from '@google/genai';

const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY || '';

export const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

/**
 * Generate content with automatic failover across models to prevent 429 Quota Exhausted crashes
 */
export async function generateContentWithFallback(params: {
  contents: any;
  config?: any;
  primaryModel?: string;
}) {
  const candidateModels = [
    params.primaryModel || 'gemini-2.5-flash',
    'gemini-2.0-flash',
    'gemini-1.5-flash',
    'gemini-2.5-flash-lite',
  ];

  let lastError: any = null;

  for (const model of candidateModels) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: params.contents,
        config: params.config,
      });
      return response;
    } catch (err: any) {
      lastError = err;
      const isQuotaError =
        err?.status === 429 ||
        err?.message?.includes('429') ||
        err?.message?.includes('RESOURCE_EXHAUSTED') ||
        err?.message?.includes('Quota exceeded');

      if (isQuotaError) {
        console.warn(`[EZUMI AI] Model '${model}' hit 429 quota limit. Retrying with next model in chain...`);
        continue;
      }
      throw err;
    }
  }

  throw lastError;
}
