import { logAudit } from '../../db/auditLogs.ts';

export interface PhoneCallIntent {
  contactName: string;
  phoneNumber: string;
  dialerUri: string;
  status: 'READY_TO_DIAL' | 'INVALID_NUMBER' | 'CONFIRMATION_REQUIRED';
  prompt: string;
}

export interface WhatsAppMessageDraft {
  contactName: string;
  phoneNumber: string;
  messageText: string;
  webUrl: string;
  status: 'DRAFT_READY' | 'INVALID_NUMBER' | 'CONFIRMATION_REQUIRED';
}

export const preparePhoneCall = async (uid: string, contactName: string, phoneNumber?: string): Promise<PhoneCallIntent> => {
  // Sanitize and normalize phone number
  const cleanNumber = (phoneNumber || '').replace(/[^0-9+]/g, '');

  if (!cleanNumber && !phoneNumber) {
    return {
      contactName,
      phoneNumber: '',
      dialerUri: '',
      status: 'CONFIRMATION_REQUIRED',
      prompt: `Aap ${contactName} ka phone number bataiye taaki call prepare ki jaa sake.`,
    };
  }

  const dialerUri = `tel:${cleanNumber}`;

  await logAudit(uid, {
    action: 'PHONE_CALL_PREPARED',
    tool: 'CallingService',
    details: `Call prepared for ${contactName} (${cleanNumber})`,
  });

  return {
    contactName,
    phoneNumber: cleanNumber,
    dialerUri,
    status: 'READY_TO_DIAL',
    prompt: `Kya aap ${contactName} (${cleanNumber}) ko call lagana chahte hain? Click karke dialer kholein.`,
  };
};

export const prepareWhatsAppMessage = async (uid: string, contactName: string, phoneNumber: string, messageText: string): Promise<WhatsAppMessageDraft> => {
  const cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
  const encodedMsg = encodeURIComponent(messageText);
  const webUrl = `https://wa.me/${cleanNumber}?text=${encodedMsg}`;

  await logAudit(uid, {
    action: 'WHATSAPP_DRAFT_CREATED',
    tool: 'MessagingService',
    details: `Draft to ${contactName} (${cleanNumber}): "${messageText}"`,
  });

  return {
    contactName,
    phoneNumber: cleanNumber,
    messageText,
    webUrl,
    status: cleanNumber.length >= 10 ? 'DRAFT_READY' : 'INVALID_NUMBER',
  };
};

export const getDeviceCapabilities = () => {
  return {
    browser: true,
    microphone: true,
    camera: true,
    screenShare: true,
    phoneCalling: 'system-intent-tel',
    whatsapp: 'web-and-app-intent',
    speechRecognition: true,
  };
};
