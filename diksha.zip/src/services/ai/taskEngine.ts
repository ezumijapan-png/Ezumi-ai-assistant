import { ai } from './geminiClient.ts';
import { Type } from '@google/genai';
import { createTask, updateTaskStatus, getTaskById } from '../../db/tasks.ts';
import { recordWorkflow, updateWorkflowValidation } from '../../db/workflows.ts';
import { logAudit } from '../../db/auditLogs.ts';

export interface TaskPlanStep {
  stepNumber: number;
  phase: 'UNDERSTAND' | 'PLAN' | 'AUTHORIZE' | 'ACT' | 'OBSERVE' | 'EVALUATE' | 'VERIFY';
  title: string;
  description: string;
  status: 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED';
  verificationCriteria: string;
}

export const planAndInitTask = async (uid: string, goal: string) => {
  let taskTitle = goal.slice(0, 40);
  let steps: TaskPlanStep[] = [];

  try {
    // 1. Decompose goal into execution steps using Gemini
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `You are the Autonomous Task Planner for EZUMI.
Decompose this user goal into a 5-step concrete autonomous plan following the lifecycle:
1. UNDERSTAND: Scope requirements and constraints.
2. PLAN: Blueprint architecture, steps, and tools.
3. AUTHORIZE & PREPARE: Verify access, environmental configs, and permissions.
4. ACT & OBSERVE: Execute core actions, inspect intermediate state.
5. EVALUATE & VERIFY: Run validation tests and verify outcomes before reporting completion.

User Goal: "${goal}"`,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            steps: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  stepNumber: { type: Type.INTEGER },
                  phase: { type: Type.STRING },
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  verificationCriteria: { type: Type.STRING },
                },
                required: ['stepNumber', 'phase', 'title', 'description', 'verificationCriteria'],
              },
            },
          },
          required: ['title', 'steps'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    taskTitle = parsed.title || goal.slice(0, 40);
    steps = (parsed.steps || []).map((s: any) => ({
      ...s,
      status: 'PENDING',
    }));
  } catch (err: any) {
    console.warn('Task planning AI fallback notice:', err?.message || err);
    taskTitle = `Project: ${goal.slice(0, 35)}`;
    steps = [
      { stepNumber: 1, phase: 'UNDERSTAND', title: 'Define Goal & Scope', description: `Analyze scope for: ${goal}`, status: 'PENDING', verificationCriteria: 'Requirements mapped' },
      { stepNumber: 2, phase: 'PLAN', title: 'System Blueprint', description: 'Design architecture and plan steps', status: 'PENDING', verificationCriteria: 'Blueprint ready' },
      { stepNumber: 3, phase: 'AUTHORIZE', title: 'Check Environment', description: 'Verify tools and required permissions', status: 'PENDING', verificationCriteria: 'Permissions verified' },
      { stepNumber: 4, phase: 'ACT', title: 'Core Implementation', description: 'Execute scheduled build tasks', status: 'PENDING', verificationCriteria: 'Artifacts generated' },
      { stepNumber: 5, phase: 'VERIFY', title: 'Testing & Validation', description: 'Run comprehensive sanity checks', status: 'PENDING', verificationCriteria: 'Success verified' },
    ];
  }

  // Create in database
  const task = await createTask(uid, {
    title: taskTitle,
    goal,
    steps: steps as any,
  });

  await logAudit(uid, {
    action: 'TASK_PLANNED',
    tool: 'taskEngine',
    details: `Task #${task.id}: ${taskTitle}`,
  });

  return task;
};

export const executeNextTaskStep = async (uid: string, taskId: number) => {
  const task = await getTaskById(taskId);
  if (!task) throw new Error('Task not found');

  if (task.status === 'PAUSED' || task.status === 'COMPLETED' || task.status === 'FAILED') {
    return task;
  }

  let steps: TaskPlanStep[] = [];
  try {
    steps = JSON.parse(task.steps);
  } catch (e) {
    steps = [];
  }

  const currentStepIndex = steps.findIndex(s => s.status === 'PENDING' || s.status === 'RUNNING');
  if (currentStepIndex === -1) {
    // All steps finished - verify and complete
    const updated = await updateTaskStatus(taskId, 'COMPLETED', 100, `Task successfully completed and verified.`);
    
    // Learn workflow from success
    try {
      await recordWorkflow(uid, {
        name: task.title,
        triggerIntent: task.goal,
        steps,
        state: 'TESTING',
        notes: 'Autonomous task completed and verified.',
      });
    } catch (wErr) {
      console.error('Workflow learning error:', wErr);
    }

    return updated;
  }

  // Advance step
  const activeStep = steps[currentStepIndex];
  activeStep.status = 'COMPLETED';

  const progress = Math.round(((currentStepIndex + 1) / steps.length) * 100);
  const nextStatus = progress === 100 ? 'COMPLETED' : 'IN_PROGRESS';
  const resultMessage = progress === 100 
    ? `Completed: ${activeStep.title}. All verification passed.`
    : `Executed: ${activeStep.title}`;

  const updated = await updateTaskStatus(taskId, nextStatus, progress, resultMessage, undefined, steps);

  if (progress === 100) {
    try {
      await recordWorkflow(uid, {
        name: task.title,
        triggerIntent: task.goal,
        steps,
        state: 'TESTING',
        notes: 'Autonomous task completed and verified.',
      });
    } catch (e) {}
  }

  return updated;
};

export const pauseTask = async (taskId: number) => {
  return updateTaskStatus(taskId, 'PAUSED');
};

export const resumeTask = async (taskId: number) => {
  return updateTaskStatus(taskId, 'IN_PROGRESS');
};
