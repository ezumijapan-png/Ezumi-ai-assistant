import { VoiceSessionState } from '../../types';

export type RecognitionMode = 'NONE' | 'DICTATION' | 'WAKE_WORD';

export interface VoiceControllerCallbacks {
  onStateChange: (state: VoiceSessionState, error?: string) => void;
  onTranscript: (transcript: string, isFinal: boolean, mode: RecognitionMode) => void;
  onWakeWordDetected?: (commandAfterWake: string, isFinal: boolean) => void;
  onPermissionStatus?: (status: 'granted' | 'denied' | 'prompt' | 'unknown') => void;
}

/**
 * VoiceController: A single, reliable controller for browser speech recognition.
 * Prevents rapid ON-OFF loops, multiple instances, stale callbacks,
 * and handles browser-specific quirks in Web Speech API.
 */
class VoiceController {
  private recognition: any = null;
  private state: VoiceSessionState = 'IDLE';
  private mode: RecognitionMode = 'NONE';
  private callbacks: VoiceControllerCallbacks | null = null;

  // Session lifecycle flags
  private isStarting = false;
  private isActive = false;
  private isExplicitlyStopped = true;
  private isPausedForSpeech = false;

  // Restart / debounce timers
  private restartTimer: number | null = null;
  private consecutiveErrors = 0;
  private maxConsecutiveErrors = 3;
  private activeSessionToken = 0;

  constructor() {
    this.checkBrowserSupport();
  }

  public isSupported(): boolean {
    return typeof window !== 'undefined' && 
      !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
  }

  private checkBrowserSupport(): boolean {
    return this.isSupported();
  }

  public setCallbacks(callbacks: VoiceControllerCallbacks) {
    this.callbacks = callbacks;
  }

  public getState(): VoiceSessionState {
    return this.state;
  }

  public getMode(): RecognitionMode {
    return this.mode;
  }

  private setState(newState: VoiceSessionState, errorMsg?: string) {
    if (this.state === newState && !errorMsg) return;
    this.state = newState;
    this.callbacks?.onStateChange(newState, errorMsg);
  }

  /**
   * Request microphone permission explicitly via getUserMedia first.
   * This provides a clean permission prompt without crashing SpeechRecognition.
   */
  public async requestMicrophonePermission(): Promise<boolean> {
    this.setState('REQUESTING_PERMISSION');
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      this.callbacks?.onPermissionStatus?.('denied');
      this.setState('ERROR', 'Audio recording is not supported in this browser.');
      return false;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // Stop the test tracks immediately so we don't hold the mic open
      stream.getTracks().forEach((track) => track.stop());
      this.callbacks?.onPermissionStatus?.('granted');
      this.setState('IDLE');
      return true;
    } catch (err: any) {
      console.warn('Microphone permission check failed:', err);
      this.callbacks?.onPermissionStatus?.('denied');
      this.setState('ERROR', 'Microphone access denied. Please enable mic permissions in your browser.');
      return false;
    }
  }

  /**
   * Ensure any existing recognition instance is safely stopped and destroyed.
   */
  private cleanupInstance() {
    this.clearRestartTimer();

    if (this.recognition) {
      try {
        // Detach handlers first so no stale onend/onerror events fire during teardown
        this.recognition.onstart = null;
        this.recognition.onresult = null;
        this.recognition.onerror = null;
        this.recognition.onend = null;
        this.recognition.abort();
      } catch (e) {
        // Ignore errors during abort
      }
      this.recognition = null;
    }

    this.isActive = false;
    this.isStarting = false;
  }

  private clearRestartTimer() {
    if (this.restartTimer !== null) {
      window.clearTimeout(this.restartTimer);
      this.restartTimer = null;
    }
  }

  /**
   * Start Manual Push-to-Talk / Click-to-Speak Dictation
   * Guarantees exclusive access to the microphone.
   */
  public startDictation(): boolean {
    if (!this.isSupported()) {
      this.setState('ERROR', 'Speech Recognition is not supported in this browser.');
      return false;
    }

    // Bump session token to invalidate any previous pending operations
    const sessionToken = ++this.activeSessionToken;
    this.isExplicitlyStopped = false;
    this.isPausedForSpeech = false;
    this.mode = 'DICTATION';
    this.consecutiveErrors = 0;

    this.cleanupInstance();
    this.initRecognition(false, sessionToken);

    return true;
  }

  /**
   * Start Continuous Hands-Free Wake-Word Detection
   * Guarantees exclusive access to the microphone with debounce backoff.
   */
  public startWakeWord(): boolean {
    if (!this.isSupported()) {
      this.setState('ERROR', 'Speech Recognition is not supported in this browser.');
      return false;
    }

    const sessionToken = ++this.activeSessionToken;
    this.isExplicitlyStopped = false;
    this.isPausedForSpeech = false;
    this.mode = 'WAKE_WORD';
    this.consecutiveErrors = 0;

    this.cleanupInstance();
    this.initRecognition(true, sessionToken);

    return true;
  }

  /**
   * Initialize and start a single, managed SpeechRecognition instance
   */
  private initRecognition(isContinuous: boolean, sessionToken: number) {
    if (sessionToken !== this.activeSessionToken || this.isExplicitlyStopped) {
      return;
    }

    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      this.setState('ERROR', 'Speech Recognition API not found.');
      return;
    }

    try {
      this.recognition = new SpeechRec();
      this.recognition.continuous = isContinuous;
      this.recognition.interimResults = true;
      this.recognition.lang = 'en-US';
      this.isStarting = true;

      this.recognition.onstart = () => {
        if (sessionToken !== this.activeSessionToken) return;
        this.isStarting = false;
        this.isActive = true;
        this.consecutiveErrors = 0;
        this.callbacks?.onPermissionStatus?.('granted');

        if (this.mode === 'DICTATION') {
          this.setState('LISTENING');
        } else if (this.mode === 'WAKE_WORD') {
          this.setState('STANDBY');
        }
      };

      this.recognition.onresult = (event: any) => {
        if (sessionToken !== this.activeSessionToken || this.isPausedForSpeech) return;

        let interimText = '';
        let finalText = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const item = event.results[i];
          if (item[0]) {
            if (item.isFinal) {
              finalText += item[0].transcript;
            } else {
              interimText += item[0].transcript;
            }
          }
        }

        const transcript = (finalText || interimText).trim();
        if (!transcript) return;

        // Mode 1: Dictation
        if (this.mode === 'DICTATION') {
          this.callbacks?.onTranscript(transcript, !!finalText, 'DICTATION');
          return;
        }

        // Mode 2: Wake Word Detection
        if (this.mode === 'WAKE_WORD') {
          this.callbacks?.onTranscript(transcript, !!finalText, 'WAKE_WORD');

          const transcriptLower = transcript.toLowerCase();
          const isWakeWordMatch =
            transcriptLower.includes('ezumi') ||
            transcriptLower.includes('izumi') ||
            transcriptLower.includes('azumi') ||
            transcriptLower.includes('ejumi') ||
            transcriptLower.includes('ayzumi');

          if (isWakeWordMatch) {
            this.setState('LISTENING');

            // Extract trailing command
            const command = transcript
              .replace(/hey\s+ezumi/gi, '')
              .replace(/ok\s+ezumi/gi, '')
              .replace(/ezumi/gi, '')
              .replace(/izumi/gi, '')
              .replace(/azumi/gi, '')
              .replace(/ejumi/gi, '')
              .replace(/ayzumi/gi, '')
              .trim();

            this.callbacks?.onWakeWordDetected?.(command, !!finalText);
          }
        }
      };

      this.recognition.onerror = (event: any) => {
        if (sessionToken !== this.activeSessionToken) return;
        const error = event.error;

        console.warn('SpeechRecognition error:', error);

        // 1. Permission denied: Permanent failure
        if (error === 'not-allowed' || error === 'service-not-allowed') {
          this.isExplicitlyStopped = true;
          this.callbacks?.onPermissionStatus?.('denied');
          this.setState('ERROR', 'Microphone permission was denied. Please allow microphone in browser settings.');
          this.cleanupInstance();
          return;
        }

        // 2. No speech: Normal browser timeout
        if (error === 'no-speech') {
          if (this.mode === 'DICTATION') {
            this.setState('STANDBY');
          }
          return;
        }

        // 3. Aborted: Expected when stopping or pausing
        if (error === 'aborted') {
          return;
        }

        // 4. Network or other transient issues: count errors
        this.consecutiveErrors++;
        if (this.consecutiveErrors >= this.maxConsecutiveErrors) {
          this.isExplicitlyStopped = true;
          this.setState('ERROR', `Voice recognition paused due to connection error (${error}). Tap mic to retry.`);
          this.cleanupInstance();
        }
      };

      this.recognition.onend = () => {
        if (sessionToken !== this.activeSessionToken) return;
        this.isActive = false;
        this.isStarting = false;

        // If stopped by user or in error state or paused for speech, do not auto-restart
        if (this.isExplicitlyStopped || this.isPausedForSpeech || this.state === 'ERROR' || this.state === 'STOPPED') {
          if (!this.isPausedForSpeech && this.state !== 'ERROR') {
            this.setState('STOPPED');
          }
          return;
        }

        // If in Dictation mode, end of utterance naturally finishes dictation
        if (this.mode === 'DICTATION') {
          this.mode = 'NONE';
          this.setState('STANDBY');
          return;
        }

        // If in Wake Word mode, debounce restart to prevent the rapid ON/OFF loop
        if (this.mode === 'WAKE_WORD') {
          this.clearRestartTimer();
          // Safe debounce delay: 400ms base + backoff on errors
          const delay = 400 + Math.min(this.consecutiveErrors * 600, 3000);

          this.restartTimer = window.setTimeout(() => {
            if (
              sessionToken === this.activeSessionToken &&
              !this.isExplicitlyStopped &&
              !this.isPausedForSpeech &&
              this.mode === 'WAKE_WORD'
            ) {
              this.cleanupInstance();
              this.initRecognition(true, sessionToken);
            }
          }, delay);
        }
      };

      // Safely start recognition
      this.recognition.start();
    } catch (err: any) {
      console.warn('Error starting speech recognition:', err);
      this.isStarting = false;
      this.isActive = false;
      this.consecutiveErrors++;

      if (this.consecutiveErrors >= this.maxConsecutiveErrors) {
        this.setState('ERROR', 'Unable to start microphone.');
      } else if (this.mode === 'WAKE_WORD' && !this.isExplicitlyStopped) {
        this.clearRestartTimer();
        this.restartTimer = window.setTimeout(() => {
          if (!this.isExplicitlyStopped && this.mode === 'WAKE_WORD') {
            this.initRecognition(true, sessionToken);
          }
        }, 1000);
      }
    }
  }

  /**
   * Pause recognition while EZUMI is speaking or synthesizing audio.
   * This prevents audio feedback loops and SpeechRecognition crashes.
   */
  public pauseForAssistantSpeaking() {
    this.isPausedForSpeech = true;
    this.setState('SPEAKING');

    if (this.recognition && this.isActive) {
      try {
        this.recognition.abort();
      } catch (e) {}
    }
    this.clearRestartTimer();
  }

  /**
   * Resume recognition after EZUMI finishes speaking.
   */
  public resumeAfterAssistantSpeaking() {
    this.isPausedForSpeech = false;

    if (this.isExplicitlyStopped) {
      this.setState('STOPPED');
      return;
    }

    if (this.mode === 'WAKE_WORD') {
      this.setState('STANDBY');
      this.clearRestartTimer();
      // Safe delay after TTS ends before re-opening mic (500ms)
      this.restartTimer = window.setTimeout(() => {
        if (!this.isExplicitlyStopped && !this.isPausedForSpeech && this.mode === 'WAKE_WORD') {
          const sessionToken = ++this.activeSessionToken;
          this.cleanupInstance();
          this.initRecognition(true, sessionToken);
        }
      }, 500);
    } else {
      this.setState('STANDBY');
    }
  }

  public setProcessing() {
    this.setState('PROCESSING');
  }

  public setStandby() {
    if (this.state !== 'SPEAKING') {
      this.setState('STANDBY');
    }
  }

  /**
   * Explicitly stop all voice recognition.
   * Will cancel any timers and ensure microphone is fully released.
   */
  public stop() {
    this.isExplicitlyStopped = true;
    this.isPausedForSpeech = false;
    this.mode = 'NONE';
    this.activeSessionToken++;
    this.cleanupInstance();
    this.setState('STOPPED');
  }
}

// Global singleton instance for clean app-wide audio state
export const voiceController = new VoiceController();
