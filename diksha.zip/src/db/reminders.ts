import { db } from './index.ts';
import { reminders, users } from './schema.ts';
import { eq, desc, and } from 'drizzle-orm';

export interface CreateReminderParams {
  title: string;
  dueAt: Date;
  priority?: string;
  repeat?: string;
}

export const createReminder = async (uid: string, params: CreateReminderParams) => {
  const userList = await db.select().from(users).where(eq(users.uid, uid)).limit(1);
  if (!userList.length) throw new Error('User not found');
  const userId = userList[0].id;

  const [newReminder] = await db.insert(reminders).values({
    userId,
    title: params.title,
    dueAt: params.dueAt,
    priority: params.priority || 'normal',
    repeat: params.repeat || 'none',
    status: 'PENDING',
  } as any).returning();

  return newReminder;
};

export const getUserReminders = async (uid: string) => {
  const userList = await db.select().from(users).where(eq(users.uid, uid)).limit(1);
  if (!userList.length) return [];
  const userId = userList[0].id;

  return db.select().from(reminders).where(eq(reminders.userId, userId)).orderBy(desc(reminders.dueAt));
};

export const updateReminderStatus = async (reminderId: number, status: 'PENDING' | 'TRIGGERED' | 'DISMISSED') => {
  const [updated] = await db.update(reminders).set({ status } as any).where(eq(reminders.id, reminderId)).returning();
  return updated;
};
