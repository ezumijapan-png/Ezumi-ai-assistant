import { db } from './index.ts';
import { vitals, users } from './schema.ts';
import { eq } from 'drizzle-orm';

export interface VitalsState {
  hydration: number;
  hunger: number;
  mood: number;
}

export async function getUserVitals(userUid: string): Promise<VitalsState | null> {
  try {
    const records = await db
      .select({
        hydration: vitals.hydration,
        hunger: vitals.hunger,
        mood: vitals.mood,
      })
      .from(vitals)
      .innerJoin(users, eq(vitals.userId, users.id))
      .where(eq(users.uid, userUid))
      .limit(1);

    if (records.length === 0) return null;
    return records[0];
  } catch (error) {
    console.error("Failed to load user vitals from Cloud SQL:", error);
    throw new Error("Failed to load vitals", { cause: error });
  }
}

export async function saveUserVitals(
  userUid: string,
  state: VitalsState
) {
  try {
    const userRecord = await db.select().from(users).where(eq(users.uid, userUid)).limit(1);
    if (!userRecord || userRecord.length === 0) {
      throw new Error("User record not found");
    }

    const userId = userRecord[0].id;
    const result = await db.insert(vitals)
      .values({
        userId,
        hydration: Math.round(state.hydration),
        hunger: Math.round(state.hunger),
        mood: Math.round(state.mood),
        updatedAt: new Date(),
      } as any)
      .onConflictDoUpdate({
        target: vitals.userId,
        set: {
          hydration: Math.round(state.hydration),
          hunger: Math.round(state.hunger),
          mood: Math.round(state.mood),
          updatedAt: new Date(),
        } as any,
      })
      .returning();

    return result[0];
  } catch (error) {
    console.error("Failed to save user vitals to Cloud SQL:", error);
    throw new Error("Failed to persist vitals", { cause: error });
  }
}
