import { db } from './index.ts';
import { notes, users } from './schema.ts';
import { eq, desc } from 'drizzle-orm';

export interface CreateNoteParams {
  title: string;
  content: string;
  tags?: string;
}

export const createNote = async (uid: string, params: CreateNoteParams) => {
  const userList = await db.select().from(users).where(eq(users.uid, uid)).limit(1);
  if (!userList.length) throw new Error('User not found');
  const userId = userList[0].id;

  const [newNote] = await db.insert(notes).values({
    userId,
    title: params.title,
    content: params.content,
    tags: params.tags || '',
    isAutoSaved: true,
  } as any).returning();

  return newNote;
};

export const getUserNotes = async (uid: string) => {
  const userList = await db.select().from(users).where(eq(users.uid, uid)).limit(1);
  if (!userList.length) return [];
  const userId = userList[0].id;

  return db.select().from(notes).where(eq(notes.userId, userId)).orderBy(desc(notes.updatedAt));
};

export const updateNote = async (noteId: number, content: string, title?: string, tags?: string) => {
  const values: any = { content, updatedAt: new Date() };
  if (title !== undefined) values.title = title;
  if (tags !== undefined) values.tags = tags;

  const [updated] = await db.update(notes).set(values as any).where(eq(notes.id, noteId)).returning();
  return updated;
};

export const deleteNote = async (noteId: number) => {
  await db.delete(notes).where(eq(notes.id, noteId));
  return true;
};
