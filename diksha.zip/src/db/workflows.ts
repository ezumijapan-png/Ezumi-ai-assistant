import { db } from './index.ts';
import { workflows, users } from './schema.ts';
import { eq, desc } from 'drizzle-orm';

export interface RecordWorkflowParams {
  name: string;
  triggerIntent: string;
  steps: any[];
  state?: 'PROPOSED' | 'TESTING' | 'VALIDATED' | 'DEPRECATED';
  notes?: string;
}

export const recordWorkflow = async (uid: string, params: RecordWorkflowParams) => {
  const userList = await db.select().from(users).where(eq(users.uid, uid)).limit(1);
  if (!userList.length) throw new Error('User not found');
  const userId = userList[0].id;

  const [workflow] = await db.insert(workflows).values({
    userId,
    name: params.name,
    triggerIntent: params.triggerIntent,
    steps: JSON.stringify(params.steps),
    state: params.state || 'PROPOSED',
    notes: params.notes || '',
  } as any).returning();

  return workflow;
};

export const getUserWorkflows = async (uid: string) => {
  const userList = await db.select().from(users).where(eq(users.uid, uid)).limit(1);
  if (!userList.length) return [];
  const userId = userList[0].id;

  return db.select().from(workflows).where(eq(workflows.userId, userId)).orderBy(desc(workflows.updatedAt));
};

export const updateWorkflowValidation = async (workflowId: number, success: boolean) => {
  const [current] = await db.select().from(workflows).where(eq(workflows.id, workflowId)).limit(1);
  if (!current) return null;

  const successCount = success ? current.successCount + 1 : current.successCount;
  const failureCount = !success ? current.failureCount + 1 : current.failureCount;
  
  // Promote to VALIDATED if 2+ successes and >=80% success rate
  let state = current.state;
  if (successCount >= 2 && successCount / (successCount + failureCount) >= 0.8) {
    state = 'VALIDATED';
  } else if (failureCount >= 3 && failureCount > successCount) {
    state = 'DEPRECATED';
  }

  const [updated] = await db.update(workflows).set({
    successCount,
    failureCount,
    state,
    updatedAt: new Date(),
  } as any).where(eq(workflows.id, workflowId)).returning();

  return updated;
};
