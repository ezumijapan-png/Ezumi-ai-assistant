import { db } from './index.ts';
import { auditLogs, users } from './schema.ts';
import { eq, desc } from 'drizzle-orm';

export interface LogAuditParams {
  action: string;
  tool: string;
  details?: string;
  status?: string;
}

export const logAudit = async (uid: string, params: LogAuditParams) => {
  try {
    const userList = await db.select().from(users).where(eq(users.uid, uid)).limit(1);
    if (!userList.length) return null;
    const userId = userList[0].id;

    const [log] = await db.insert(auditLogs).values({
      userId,
      action: params.action,
      tool: params.tool,
      details: params.details || '',
      status: params.status || 'SUCCESS',
    } as any).returning();

    return log;
  } catch (err) {
    console.error('Audit log failure:', err);
    return null;
  }
};

export const getUserAuditLogs = async (uid: string) => {
  const userList = await db.select().from(users).where(eq(users.uid, uid)).limit(1);
  if (!userList.length) return [];
  const userId = userList[0].id;

  return db.select().from(auditLogs).where(eq(auditLogs.userId, userId)).orderBy(desc(auditLogs.createdAt)).limit(50);
};
