import { db } from './index.ts';
import { researches, users } from './schema.ts';
import { eq, desc } from 'drizzle-orm';

export interface SaveResearchParams {
  query: string;
  topic?: string;
  summary: string;
  sources: Array<{ title: string; url: string; snippet?: string }>;
}

export const saveResearch = async (uid: string, params: SaveResearchParams) => {
  const userList = await db.select().from(users).where(eq(users.uid, uid)).limit(1);
  if (!userList.length) throw new Error('User not found');
  const userId = userList[0].id;

  const [saved] = await db.insert(researches).values({
    userId,
    query: params.query,
    topic: params.topic || 'general',
    summary: params.summary,
    sources: JSON.stringify(params.sources || []),
  } as any).returning();

  return saved;
};

export const getUserResearches = async (uid: string) => {
  const userList = await db.select().from(users).where(eq(users.uid, uid)).limit(1);
  if (!userList.length) return [];
  const userId = userList[0].id;

  return db.select().from(researches).where(eq(researches.userId, userId)).orderBy(desc(researches.createdAt)).limit(20);
};
