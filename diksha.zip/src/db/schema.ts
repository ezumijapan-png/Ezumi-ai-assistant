import { relations } from 'drizzle-orm';
import { boolean, integer, jsonb, pgTable, serial, text, timestamp, uniqueIndex } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull(),
  email: text('email').notNull(),
  name: text('name'),
  createdAt: timestamp('created_at').defaultNow(),
}, (table) => ({
  uidIndex: uniqueIndex('users_uid_idx').on(table.uid),
}));

export const memories = pgTable('memories', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull(),
  role: text('role').notNull(),
  text: text('text').notNull(),
  category: text('category').default('conversation'), // conversation, preference, project, fact
  createdAt: timestamp('created_at').defaultNow(),
});

export const vitals = pgTable('vitals', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull(),
  hydration: integer('hydration').notNull().default(85),
  hunger: integer('hunger').notNull().default(20),
  mood: integer('mood').notNull().default(100),
  updatedAt: timestamp('updated_at').defaultNow(),
}, (table) => ({
  userIdIndex: uniqueIndex('vitals_user_id_idx').on(table.userId),
}));

export const tasks = pgTable('tasks', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull(),
  title: text('title').notNull(),
  goal: text('goal').notNull(),
  status: text('status').notNull().default('PLANNED'), // PLANNED, IN_PROGRESS, PAUSED, COMPLETED, FAILED
  progress: integer('progress').notNull().default(0),
  steps: text('steps').notNull().default('[]'),
  result: text('result'),
  error: text('error'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const notes = pgTable('notes', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull(),
  title: text('title').notNull(),
  content: text('content').notNull().default(''),
  tags: text('tags').default(''),
  isAutoSaved: boolean('is_auto_saved').default(true),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const researches = pgTable('researches', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull(),
  query: text('query').notNull(),
  topic: text('topic').default('general'),
  summary: text('summary').notNull(),
  sources: text('sources').notNull().default('[]'), // json string of sources with title & url
  createdAt: timestamp('created_at').defaultNow(),
});

export const workflows = pgTable('workflows', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull(),
  name: text('name').notNull(),
  triggerIntent: text('trigger_intent').notNull(),
  steps: text('steps').notNull().default('[]'),
  state: text('state').notNull().default('PROPOSED'), // PROPOSED, TESTING, VALIDATED, DEPRECATED
  successCount: integer('success_count').notNull().default(0),
  failureCount: integer('failure_count').notNull().default(0),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const reminders = pgTable('reminders', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull(),
  title: text('title').notNull(),
  dueAt: timestamp('due_at').notNull(),
  status: text('status').notNull().default('PENDING'), // PENDING, TRIGGERED, DISMISSED
  priority: text('priority').default('normal'),
  repeat: text('repeat').default('none'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const auditLogs = pgTable('audit_logs', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull(),
  action: text('action').notNull(),
  tool: text('tool').notNull(),
  details: text('details'),
  status: text('status').notNull().default('SUCCESS'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const usersRelations = relations(users, ({ many, one }) => ({
  memories: many(memories),
  tasks: many(tasks),
  notes: many(notes),
  researches: many(researches),
  workflows: many(workflows),
  reminders: many(reminders),
  auditLogs: many(auditLogs),
  vitals: one(vitals, {
    fields: [users.id],
    references: [vitals.userId],
  }),
}));
