import { db } from './index.ts';
import { tasks, users } from './schema.ts';
import { eq, desc, and } from 'drizzle-orm';

export interface CreateTaskParams {
  title: string;
  goal: string;
  steps?: string[];
}

export const createTask = async (uid: string, params: CreateTaskParams) => {
  const userList = await db.select().from(users).where(eq(users.uid, uid)).limit(1);
  if (!userList.length) throw new Error('User not found');
  const userId = userList[0].id;

  const [newTask] = await db.insert(tasks).values({
    userId,
    title: params.title,
    goal: params.goal,
    status: 'PLANNED',
    progress: 0,
    steps: JSON.stringify(params.steps || []),
  } as any).returning();

  return newTask;
};

export const getUserTasks = async (uid: string) => {
  const userList = await db.select().from(users).where(eq(users.uid, uid)).limit(1);
  if (!userList.length) return [];
  const userId = userList[0].id;

  return db.select().from(tasks).where(eq(tasks.userId, userId)).orderBy(desc(tasks.updatedAt));
};

export const updateTaskStatus = async (taskId: number, status: string, progress?: number, result?: string, error?: string, steps?: any[]) => {
  const values: any = { status, updatedAt: new Date() };
  if (progress !== undefined) values.progress = progress;
  if (result !== undefined) values.result = result;
  if (error !== undefined) values.error = error;
  if (steps !== undefined) values.steps = JSON.stringify(steps);

  const [updated] = await db.update(tasks).set(values as any).where(eq(tasks.id, taskId)).returning();
  return updated;
};

export const getTaskById = async (taskId: number) => {
  const [task] = await db.select().from(tasks).where(eq(tasks.id, taskId)).limit(1);
  return task || null;
};
