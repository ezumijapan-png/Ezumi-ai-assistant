import { db } from './index.ts';
import { memories, users } from './schema.ts';
import { eq, desc, asc } from 'drizzle-orm';

export interface MemoryItem {
  id?: number;
  role: 'user' | 'assistant';
  text: string;
  timestamp: Date;
}

export async function getUserMemories(userUid: string): Promise<MemoryItem[]> {
  try {
    const records = await db
      .select({
        id: memories.id,
        role: memories.role,
        text: memories.text,
        createdAt: memories.createdAt,
      })
      .from(memories)
      .innerJoin(users, eq(memories.userId, users.id))
      .where(eq(users.uid, userUid))
      .orderBy(asc(memories.createdAt));

    return records.map((r) => ({
      id: r.id,
      role: r.role as 'user' | 'assistant',
      text: r.text,
      timestamp: r.createdAt ? new Date(r.createdAt) : new Date(),
    }));
  } catch (error) {
    console.error("Failed to load user memories from Cloud SQL:", error);
    throw new Error("Failed to load conversation memories", { cause: error });
  }
}

export async function saveUserMemory(
  userUid: string,
  role: 'user' | 'assistant',
  text: string
) {
  try {
    const userRecord = await db.select().from(users).where(eq(users.uid, userUid)).limit(1);
    if (!userRecord || userRecord.length === 0) {
      throw new Error("User record not found");
    }

    const inserted = await db.insert(memories)
      .values({
        userId: userRecord[0].id,
        role,
        text,
      })
      .returning();

    return inserted[0];
  } catch (error) {
    console.error("Failed to save memory to Cloud SQL:", error);
    throw new Error("Failed to persist conversation memory", { cause: error });
  }
}

export async function clearUserMemories(userUid: string) {
  try {
    const userRecord = await db.select().from(users).where(eq(users.uid, userUid)).limit(1);
    if (!userRecord || userRecord.length === 0) {
      return;
    }

    await db.delete(memories).where(eq(memories.userId, userRecord[0].id));
  } catch (error) {
    console.error("Failed to clear memories from Cloud SQL:", error);
    throw new Error("Failed to clear memories", { cause: error });
  }
}
