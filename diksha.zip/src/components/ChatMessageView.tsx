import React, { useState } from 'react';
import { 
  Sparkles, Copy, Check, Volume2, VolumeX, User, Bot, 
  Terminal, Globe, FileText, Video, ArrowRight
} from 'lucide-react';
import { TranscriptionTurn } from '../../types';

interface ChatMessageViewProps {
  turns: TranscriptionTurn[];
  isProcessing: boolean;
  onSpeak: (text: string) => void;
  onSelectPrompt: (prompt: string) => void;
  onOpenVideoCall: () => void;
  onOpenResearch: () => void;
  onOpenTasks: () => void;
  onOpenNotes: () => void;
}

export const ChatMessageView: React.FC<ChatMessageViewProps> = ({
  turns,
  isProcessing,
  onSpeak,
  onSelectPrompt,
  onOpenVideoCall,
  onOpenResearch,
  onOpenTasks,
  onOpenNotes,
}) => {
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  const copyToClipboard = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  if (turns.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-4 sm:p-8 max-w-2xl mx-auto text-center select-none animate-in fade-in duration-500">
        {/* Empty State Welcome */}
        <div className="w-16 h-16 rounded-2xl bg-[#121212] border border-[#2B2B2B] flex items-center justify-center shadow-xl mb-4 relative">
          <Sparkles className="w-8 h-8 text-white" />
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-black" />
        </div>

        <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight mb-2">
          How can EZUMI assist you today?
        </h2>
        <p className="text-xs sm:text-sm text-[#A0A0A0] max-w-md mb-8 leading-relaxed">
          I am your personal AI companion. Speak with me hands-free by saying <strong className="text-white">"Ezumi"</strong>, type questions below, or choose a capability:
        </p>

        {/* Suggestion Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 w-full text-left">
          <button
            onClick={() => onSelectPrompt('Summarize the top global tech news today')}
            className="p-3.5 rounded-xl bg-[#101010] hover:bg-[#161616] border border-[#222222] hover:border-[#333333] transition-all group"
          >
            <div className="flex items-center gap-2 text-xs font-semibold text-white mb-1">
              <Globe className="w-3.5 h-3.5 text-blue-400" />
              <span>Latest News & Research</span>
            </div>
            <p className="text-[11px] text-[#808080] group-hover:text-[#A0A0A0] transition-colors">
              "Summarize the top global tech news today"
            </p>
          </button>

          <button
            onClick={() => onSelectPrompt('Plan an autonomous workflow for launching my Android application')}
            className="p-3.5 rounded-xl bg-[#101010] hover:bg-[#161616] border border-[#222222] hover:border-[#333333] transition-all group"
          >
            <div className="flex items-center gap-2 text-xs font-semibold text-white mb-1">
              <Terminal className="w-3.5 h-3.5 text-purple-400" />
              <span>Autonomous Task Planning</span>
            </div>
            <p className="text-[11px] text-[#808080] group-hover:text-[#A0A0A0] transition-colors">
              "Plan an autonomous workflow for my app"
            </p>
          </button>

          <button
            onClick={() => onOpenVideoCall()}
            className="p-3.5 rounded-xl bg-[#101010] hover:bg-[#161616] border border-[#222222] hover:border-[#333333] transition-all group"
          >
            <div className="flex items-center gap-2 text-xs font-semibold text-white mb-1">
              <Video className="w-3.5 h-3.5 text-emerald-400" />
              <span>Face-to-Face Vision Call</span>
            </div>
            <p className="text-[11px] text-[#808080] group-hover:text-[#A0A0A0] transition-colors">
              "Start live camera and interactive vision call"
            </p>
          </button>

          <button
            onClick={() => onOpenNotes()}
            className="p-3.5 rounded-xl bg-[#101010] hover:bg-[#161616] border border-[#222222] hover:border-[#333333] transition-all group"
          >
            <div className="flex items-center gap-2 text-xs font-semibold text-white mb-1">
              <FileText className="w-3.5 h-3.5 text-amber-400" />
              <span>Smart Voice Notepad</span>
            </div>
            <p className="text-[11px] text-[#808080] group-hover:text-[#A0A0A0] transition-colors">
              "Save ideas and thoughts with voice dictation"
            </p>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 w-full max-w-3xl mx-auto px-4 py-4 space-y-5">
      {turns.map((turn, idx) => {
        const isUser = turn.role === 'user';
        return (
          <div
            key={idx}
            className={`flex gap-3 sm:gap-4 animate-in fade-in duration-300 ${
              isUser ? 'justify-end' : 'justify-start'
            }`}
          >
            {/* Assistant Avatar Icon */}
            {!isUser && (
              <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-[#141414] border border-[#282828] flex items-center justify-center shrink-0 mt-0.5 text-white">
                <Bot className="w-4 h-4" />
              </div>
            )}

            {/* Message Bubble */}
            <div
              className={`max-w-[85%] sm:max-w-[80%] rounded-2xl px-4 py-3 text-xs sm:text-sm leading-relaxed ${
                isUser
                  ? 'bg-[#1C1C1C] text-white border border-[#2E2E2E] rounded-tr-none'
                  : 'bg-[#0E0E0E] text-[#EDEDED] border border-[#222222] rounded-tl-none'
              }`}
            >
              {/* Sender & Timestamp */}
              <div className="flex items-center justify-between gap-3 text-[10px] text-[#707070] mb-1 font-semibold uppercase tracking-wider">
                <span>{isUser ? 'You' : 'EZUMI'}</span>
                <span>
                  {turn.timestamp instanceof Date
                    ? turn.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                    : ''}
                </span>
              </div>

              {/* Message Content */}
              <div className="whitespace-pre-wrap break-words">{turn.text}</div>

              {/* Action Buttons for AI responses */}
              {!isUser && (
                <div className="flex items-center gap-2 mt-2 pt-2 border-t border-[#1C1C1C] text-[#808080]">
                  <button
                    onClick={() => copyToClipboard(turn.text, idx)}
                    className="p-1 rounded hover:bg-[#1A1A1A] hover:text-white transition-colors"
                    title="Copy response"
                  >
                    {copiedIdx === idx ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>

                  <button
                    onClick={() => onSpeak(turn.text)}
                    className="p-1 rounded hover:bg-[#1A1A1A] hover:text-white transition-colors"
                    title="Read aloud"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            {/* User Avatar Icon */}
            {isUser && (
              <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-[#222222] border border-[#333333] flex items-center justify-center shrink-0 mt-0.5 text-white">
                <User className="w-4 h-4 text-[#A0A0A0]" />
              </div>
            )}
          </div>
        );
      })}

      {/* Typing / Processing Indicator */}
      {isProcessing && (
        <div className="flex gap-3 sm:gap-4 justify-start animate-in fade-in">
          <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-[#141414] border border-[#282828] flex items-center justify-center shrink-0 text-white">
            <Bot className="w-4 h-4 animate-spin text-purple-400" />
          </div>
          <div className="bg-[#0E0E0E] border border-[#222222] rounded-2xl rounded-tl-none px-4 py-3 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-white animate-bounce [animation-delay:0ms]" />
            <span className="w-1.5 h-1.5 rounded-full bg-white animate-bounce [animation-delay:150ms]" />
            <span className="w-1.5 h-1.5 rounded-full bg-white animate-bounce [animation-delay:300ms]" />
          </div>
        </div>
      )}
    </div>
  );
};
