import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, Play, Pause, RefreshCw, Plus, 
  Terminal, Sparkles, X, Loader2, ArrowRight, ShieldCheck, 
  Layers, AlertTriangle, BookOpen 
} from 'lucide-react';

interface Task {
  id: number;
  title: string;
  goal: string;
  status: 'PLANNED' | 'IN_PROGRESS' | 'PAUSED' | 'COMPLETED' | 'FAILED';
  progress: number;
  steps: string; // JSON string
  result?: string;
  error?: string;
  createdAt: string;
}

interface Workflow {
  id: number;
  name: string;
  triggerIntent: string;
  state: string;
  successCount: number;
}

interface AutonomousTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  token: string | null;
}

export const AutonomousTaskModal: React.FC<AutonomousTaskModalProps> = ({
  isOpen,
  onClose,
  token,
}) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [activeTask, setActiveTask] = useState<Task | null>(null);
  const [newGoalInput, setNewGoalInput] = useState('');
  const [planning, setPlanning] = useState(false);
  const [executing, setExecuting] = useState(false);
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState<'tasks' | 'workflows'>('tasks');

  const fetchTasksAndWorkflows = async () => {
    if (!token) return;
    setLoading(true);
    try {
      const [tRes, wRes] = await Promise.all([
        fetch('/api/tasks', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/workflows', { headers: { Authorization: `Bearer ${token}` } }),
      ]);
      if (tRes.ok) {
        const tData = await tRes.json();
        setTasks(tData.tasks || []);
        if (tData.tasks?.length && !activeTask) {
          setActiveTask(tData.tasks[0]);
        }
      }
      if (wRes.ok) {
        const wData = await wRes.json();
        setWorkflows(wData.workflows || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchTasksAndWorkflows();
    }
  }, [isOpen, token]);

  const handlePlanTask = async () => {
    if (!newGoalInput.trim() || !token) return;
    setPlanning(true);
    try {
      const res = await fetch('/api/tasks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ goal: newGoalInput.trim() }),
      });
      if (res.ok) {
        const data = await res.json();
        setTasks(prev => [data.task, ...prev]);
        setActiveTask(data.task);
        setNewGoalInput('');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setPlanning(false);
    }
  };

  const handleExecuteNextStep = async (taskId: number) => {
    if (!token) return;
    setExecuting(true);
    try {
      const res = await fetch(`/api/tasks/${taskId}/step`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setActiveTask(data.task);
        setTasks(prev => prev.map(t => t.id === taskId ? data.task : t));
      }
    } catch (e) {
      console.error(e);
    } finally {
      setExecuting(false);
    }
  };

  const handleTogglePause = async (taskId: number, currentStatus: string) => {
    if (!token) return;
    const action = currentStatus === 'PAUSED' ? 'resume' : 'pause';
    try {
      const res = await fetch(`/api/tasks/${taskId}/status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ action }),
      });
      if (res.ok) {
        const data = await res.json();
        setActiveTask(data.task);
        setTasks(prev => prev.map(t => t.id === taskId ? data.task : t));
      }
    } catch (e) {
      console.error(e);
    }
  };

  if (!isOpen) return null;

  let parsedSteps: any[] = [];
  if (activeTask?.steps) {
    try { parsedSteps = JSON.parse(activeTask.steps); } catch (e) {}
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xl flex items-center justify-center p-4">
      <div className="w-full max-w-3xl bg-[#0f0412] border border-purple-500/30 rounded-[2rem] p-5 md:p-6 shadow-[0_0_80px_rgba(168,85,247,0.2)] flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-300">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                EZUMI Autonomous Task Engine
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 font-semibold">
                  Goal Planner & Verification
                </span>
              </h2>
              <p className="text-xs text-white/50">Plan, authorize, execute, observe, evaluate, aur results verify karein</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-white/50 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switchers */}
        <div className="flex gap-2 my-3">
          <button
            onClick={() => setTab('tasks')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              tab === 'tasks' 
                ? 'bg-purple-600 text-white shadow-md' 
                : 'bg-white/5 text-white/60 hover:text-white'
            }`}
          >
            Active Tasks ({tasks.length})
          </button>
          <button
            onClick={() => setTab('workflows')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              tab === 'workflows' 
                ? 'bg-purple-600 text-white shadow-md' 
                : 'bg-white/5 text-white/60 hover:text-white'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Learned Workflows ({workflows.length})</span>
          </button>
        </div>

        {tab === 'tasks' ? (
          <>
            {/* Create Task Input */}
            <div className="flex gap-2 mb-4">
              <input
                type="text"
                value={newGoalInput}
                onChange={(e) => setNewGoalInput(e.target.value)}
                placeholder="Naya autonomous goal dein (e.g. 'Build portfolio website with contact form')..."
                className="flex-1 bg-white/5 border border-white/10 rounded-2xl px-4 py-2.5 text-xs text-white placeholder:text-white/30 focus:outline-none focus:border-purple-500/50"
                onKeyDown={(e) => e.key === 'Enter' && handlePlanTask()}
              />
              <button
                onClick={handlePlanTask}
                disabled={planning || !newGoalInput.trim()}
                className="px-5 py-2.5 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-md active:scale-95 disabled:opacity-50"
              >
                {planning ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                <span>Plan Karein</span>
              </button>
            </div>

            {/* Task View Body */}
            <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4 overflow-hidden min-h-[300px]">
              
              {/* Task Selector Sidebar */}
              <div className="md:col-span-1 border border-white/10 rounded-2xl p-3 bg-black/30 overflow-y-auto space-y-2">
                <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest block mb-2">Projects / Tasks</span>
                {tasks.length === 0 ? (
                  <div className="text-center py-8 text-white/30 text-xs italic">
                    Koi active task nahi hai. Upar naya goal enter karein!
                  </div>
                ) : (
                  tasks.map(t => (
                    <div
                      key={t.id}
                      onClick={() => setActiveTask(t)}
                      className={`p-2.5 rounded-xl cursor-pointer transition-all border ${
                        activeTask?.id === t.id 
                          ? 'bg-purple-950/60 border-purple-500/40 text-purple-100' 
                          : 'bg-white/5 border-transparent text-white/60 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      <div className="font-semibold text-xs truncate">{t.title}</div>
                      <div className="flex items-center justify-between mt-1 text-[10px]">
                        <span className={`px-1.5 py-0.5 rounded-md font-bold uppercase ${
                          t.status === 'COMPLETED' ? 'bg-emerald-500/20 text-emerald-300' :
                          t.status === 'IN_PROGRESS' ? 'bg-blue-500/20 text-blue-300' :
                          t.status === 'PAUSED' ? 'bg-orange-500/20 text-orange-300' : 'bg-white/10 text-white/60'
                        }`}>
                          {t.status}
                        </span>
                        <span className="text-white/40">{t.progress}%</span>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Task Details and Step Progression */}
              <div className="md:col-span-2 border border-white/10 rounded-2xl p-4 bg-black/40 flex flex-col justify-between overflow-hidden">
                {activeTask ? (
                  <div className="flex-1 flex flex-col overflow-hidden">
                    
                    <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-3">
                      <div>
                        <h3 className="font-bold text-sm text-white">{activeTask.title}</h3>
                        <p className="text-xs text-white/50">{activeTask.goal}</p>
                      </div>
                      <div className="text-right">
                        <span className="text-base font-mono font-bold text-purple-300">{activeTask.progress}%</span>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden mb-3">
                      <div 
                        className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-700" 
                        style={{ width: `${activeTask.progress}%` }} 
                      />
                    </div>

                    {/* Steps Timeline */}
                    <div className="flex-1 overflow-y-auto space-y-2 pr-1 my-1">
                      {parsedSteps.map((s, idx) => (
                        <div 
                          key={idx}
                          className={`p-2.5 rounded-xl border text-xs flex items-start gap-2.5 ${
                            s.status === 'COMPLETED' 
                              ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-100' 
                              : s.status === 'RUNNING' 
                                ? 'bg-purple-950/40 border-purple-500/40 text-purple-200 animate-pulse'
                                : 'bg-white/5 border-white/5 text-white/50'
                          }`}
                        >
                          <div className="mt-0.5">
                            {s.status === 'COMPLETED' ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                            ) : (
                              <div className="w-4 h-4 rounded-full border border-white/30 flex items-center justify-center text-[9px] font-mono">
                                {idx + 1}
                              </div>
                            )}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-white/90">{s.title}</span>
                              <span className="text-[9px] uppercase px-1.5 py-0.2 rounded bg-white/10 font-mono text-purple-300">
                                {s.phase}
                              </span>
                            </div>
                            <p className="text-[11px] text-white/60 mt-0.5">{s.description}</p>
                            {s.verificationCriteria && (
                              <div className="mt-1 flex items-center gap-1 text-[10px] text-emerald-400/80">
                                <ShieldCheck className="w-3 h-3" />
                                <span>Verify: {s.verificationCriteria}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Execution Controls */}
                    <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {activeTask.status !== 'COMPLETED' && (
                          <button
                            onClick={() => handleTogglePause(activeTask.id, activeTask.status)}
                            className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white/80 text-xs font-semibold flex items-center gap-1.5"
                          >
                            {activeTask.status === 'PAUSED' ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                            <span>{activeTask.status === 'PAUSED' ? 'Resume' : 'Pause'}</span>
                          </button>
                        )}
                      </div>

                      {activeTask.status !== 'COMPLETED' ? (
                        <button
                          onClick={() => handleExecuteNextStep(activeTask.id)}
                          disabled={executing || activeTask.status === 'PAUSED'}
                          className="px-5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 disabled:opacity-50"
                        >
                          {executing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <ArrowRight className="w-3.5 h-3.5" />}
                          <span>Agla Step Execute & Verify Karein</span>
                        </button>
                      ) : (
                        <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Task Verified & Learned!</span>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-white/40 text-sm">
                    Koi task selected nahi hai
                  </div>
                )}
              </div>
            </div>
          </>
        ) : (
          /* Learned Workflows Tab */
          <div className="flex-1 overflow-y-auto space-y-2 p-2 min-h-[300px]">
            <p className="text-xs text-white/50 mb-3">
              EZUMI har verified task ke baad reusable procedure record karti hai taaki future tasks tez aur accurate ho sakein.
            </p>
            {workflows.length === 0 ? (
              <div className="text-center py-12 text-white/30 text-xs italic">
                Abhi tak koi workflow record nahi hua. Tasks complete hone par yahan validated workflows aayenge.
              </div>
            ) : (
              workflows.map(w => (
                <div key={w.id} className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-sm text-white">{w.name}</h4>
                    <p className="text-xs text-white/50">{w.triggerIntent}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold uppercase">
                      {w.state}
                    </span>
                    <span className="text-xs text-white/40">{w.successCount} Successes</span>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
