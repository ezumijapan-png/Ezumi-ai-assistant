import React, { useState } from 'react';
import { 
  Video, VideoOff, Mic, MicOff, PhoneOff, FlipHorizontal, 
  Droplets, Utensils, Heart, Sparkles, Eye, Columns, 
  Maximize2, Minimize2, AlertCircle, RefreshCw, Monitor, MonitorOff, X
} from 'lucide-react';
import { VaniAvatar } from './VaniAvatar';
import { TranscriptionTurn } from '../../types';

interface VideoCallStageProps {
  videoRef: React.RefObject<HTMLVideoElement | null>;
  cameraActive: boolean;
  cameraLoading: boolean;
  cameraError: string | null;
  cameraFacingMode: 'user' | 'environment';
  micMuted: boolean;
  isVaniSpeaking: boolean;
  callDuration: number;
  mood: number;
  hydration: number;
  hunger: number;
  latestTurn?: TranscriptionTurn;
  aiName?: string;
  isScreenSharing?: boolean;
  onToggleCamera: () => void;
  onToggleFacingMode: () => void;
  onToggleMic: () => void;
  onToggleScreenShare?: () => void;
  onEndCall: () => void;
  onCareAction: (type: 'water' | 'food' | 'pyaar') => void;
}

export const VideoCallStage: React.FC<VideoCallStageProps> = ({
  videoRef,
  cameraActive,
  cameraLoading,
  cameraError,
  cameraFacingMode,
  micMuted,
  isVaniSpeaking,
  callDuration,
  mood,
  hydration,
  hunger,
  latestTurn,
  aiName = 'EZUMI',
  isScreenSharing = false,
  onToggleCamera,
  onToggleFacingMode,
  onToggleMic,
  onToggleScreenShare,
  onEndCall,
  onCareAction,
}) => {
  const [layoutMode, setLayoutMode] = useState<'pip' | 'split'>('pip');
  const [pipPosition, setPipPosition] = useState<'bottom-right' | 'top-right' | 'bottom-left'>('bottom-right');
  const [errorDismissed, setErrorDismissed] = useState(false);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const isUpset = mood < 40;

  return (
    <div className="relative w-full max-w-2xl h-[76vh] min-h-[520px] max-h-[720px] bg-[#0c040e]/90 backdrop-blur-2xl rounded-[2.5rem] border border-pink-500/20 shadow-[0_0_80px_rgba(219,39,119,0.18)] overflow-hidden flex flex-col justify-between p-4 md:p-6 transition-all">
      
      {/* Background Mood Ambient Lights */}
      <div className={`absolute inset-0 pointer-events-none transition-all duration-1000 ${
        isUpset 
          ? 'bg-radial-at-c from-purple-950/40 via-transparent to-transparent' 
          : 'bg-radial-at-c from-pink-950/30 via-transparent to-transparent'
      }`} />

      {/* Top Header Controls */}
      <div className="relative z-30 flex items-center justify-between px-2">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 border border-white/10 backdrop-blur-md">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
            <span className="text-xs font-mono font-bold tracking-wider text-pink-100">{formatTime(callDuration)}</span>
          </div>

          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full bg-pink-950/60 border border-pink-500/30 text-pink-300 text-xs font-medium">
            <Sparkles className="w-3.5 h-3.5 text-pink-400" />
            <span>Face-to-Face Live</span>
          </div>
        </div>

        {/* Layout & Status switchers */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setLayoutMode(prev => prev === 'pip' ? 'split' : 'pip')}
            className="p-2 rounded-2xl bg-white/5 hover:bg-white/15 border border-white/10 text-white/70 hover:text-white transition-all"
            title={layoutMode === 'pip' ? "Switch to Split View" : "Switch to Picture-in-Picture"}
          >
            <Columns className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Video Call Area (Split or PiP) */}
      <div className="relative z-10 flex-1 my-3 w-full flex items-center justify-center overflow-hidden rounded-3xl">
        
        {layoutMode === 'split' ? (
          /* Split View Layout */
          <div className="w-full h-full grid grid-cols-1 md:grid-cols-2 gap-3 p-1">
            {/* Left/Top: Hero Video Window */}
            <div className="relative h-full min-h-[220px] rounded-2xl overflow-hidden bg-black/60 border border-white/10 flex items-center justify-center shadow-lg group">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover transition-opacity duration-300 ${
                  cameraActive ? 'opacity-100' : 'opacity-0'
                } ${cameraFacingMode === 'user' ? 'transform scale-x-[-1]' : ''}`}
              />

              {!cameraActive && (
                <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center bg-[#150719]/90">
                  <div className="w-14 h-14 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mb-3">
                    <VideoOff className="w-6 h-6 text-white/40" />
                  </div>
                  <p className="text-sm font-semibold text-pink-200">Aapka camera band hai</p>
                  <p className="text-xs text-white/50 mb-3">Vani ko apna chehra dikhane ke liye camera on karein</p>
                  <button
                    onClick={onToggleCamera}
                    disabled={cameraLoading}
                    className="px-4 py-1.5 rounded-full bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold transition-all shadow-md active:scale-95 flex items-center gap-1.5"
                  >
                    {cameraLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Video className="w-3.5 h-3.5" />}
                    <span>Camera Chalu Karein</span>
                  </button>
                </div>
              )}

              {/* Overlay Badges */}
              <div className="absolute top-3 left-3 flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-[10px] font-semibold text-white/90 border border-white/10">
                  Hero (Aap)
                </span>
                {cameraActive && (
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[9px] font-bold">
                    640p • 1 FPS Live
                  </span>
                )}
              </div>

              {cameraActive && (
                <button
                  onClick={onToggleFacingMode}
                  className="absolute top-3 right-3 p-2 rounded-full bg-black/60 backdrop-blur-md text-white/80 hover:text-white border border-white/10 transition-all opacity-80 hover:opacity-100"
                  title="Flip Camera (Front/Back)"
                >
                  <FlipHorizontal className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Right/Bottom: Vani's Live Avatar Window */}
            <div className="relative h-full min-h-[220px] rounded-2xl overflow-hidden bg-gradient-to-b from-[#18091c] to-[#0d0310] border border-pink-500/20 flex flex-col items-center justify-center p-4 shadow-lg">
              <VaniAvatar 
                isSpeaking={isVaniSpeaking} 
                mood={mood} 
                cameraActive={cameraActive}
                size="md" 
                aiName={aiName}
              />
              <div className="absolute top-3 left-3">
                <span className="px-2.5 py-1 rounded-full bg-pink-950/70 backdrop-blur-md text-[10px] font-semibold text-pink-200 border border-pink-500/30">
                  {aiName} (Companion)
                </span>
              </div>
            </div>
          </div>
        ) : (
          /* Picture-in-Picture Layout (Full Vani Stage + Floating Hero Camera) */
          <div className="relative w-full h-full flex flex-col items-center justify-center">
            
            {/* Center Stage: Vani Avatar */}
            <div className="flex-1 flex flex-col items-center justify-center py-4">
              <VaniAvatar 
                isSpeaking={isVaniSpeaking} 
                mood={mood} 
                cameraActive={cameraActive}
                size="full" 
              />
            </div>

            {/* Floating Hero PiP Camera Feed */}
            <div className={`absolute z-20 w-36 h-48 sm:w-44 sm:h-56 rounded-2xl overflow-hidden shadow-2xl border-2 transition-all duration-300 ${
              cameraActive 
                ? 'border-pink-400/50 bg-black/80 ring-4 ring-pink-500/20' 
                : 'border-white/20 bg-[#17081b]/95'
            } ${
              pipPosition === 'bottom-right' ? 'bottom-2 right-2' : 
              pipPosition === 'top-right' ? 'top-2 right-2' : 'bottom-2 left-2'
            }`}>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover ${
                  cameraActive ? 'opacity-100' : 'opacity-0'
                } ${cameraFacingMode === 'user' ? 'transform scale-x-[-1]' : ''}`}
              />

              {!cameraActive && (
                <div className="absolute inset-0 flex flex-col items-center justify-center p-2 text-center">
                  <VideoOff className="w-6 h-6 text-white/30 mb-1.5" />
                  <p className="text-[11px] font-bold text-pink-200">Camera Off</p>
                  <button
                    onClick={onToggleCamera}
                    disabled={cameraLoading}
                    className="mt-2 px-2.5 py-1 rounded-full bg-pink-600 hover:bg-pink-500 text-white text-[10px] font-bold transition-all shadow-md active:scale-95 flex items-center gap-1"
                  >
                    {cameraLoading ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Video className="w-3 h-3" />}
                    <span>On</span>
                  </button>
                </div>
              )}

              {/* PiP Controls Overlay */}
              <div className="absolute top-1.5 left-1.5 right-1.5 flex justify-between items-center pointer-events-auto">
                <span className="px-1.5 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-[8px] font-bold text-white/80">
                  Hero
                </span>
                {cameraActive && (
                  <button
                    onClick={onToggleFacingMode}
                    className="p-1 rounded-md bg-black/70 backdrop-blur-md text-white/80 hover:text-white border border-white/10"
                    title="Flip camera"
                  >
                    <FlipHorizontal className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Live Subtitle Overlay */}
        {latestTurn && (
          <div className="absolute bottom-3 left-4 right-4 z-20 flex justify-center pointer-events-none">
            <div className="max-w-md bg-black/75 backdrop-blur-md px-5 py-2.5 rounded-2xl border border-white/15 shadow-xl animate-in fade-in slide-in-from-bottom-2 text-center pointer-events-auto">
              <span className="text-[9px] uppercase font-bold tracking-widest text-pink-400 block mb-0.5">
                {latestTurn.role === 'user' ? 'Hero' : 'Vani'}
              </span>
              <p className="text-sm font-medium text-pink-100 leading-snug">
                "{latestTurn.text}"
              </p>
            </div>
          </div>
        )}

        {/* Camera Permission / Device Notice Banner */}
        {cameraError && !errorDismissed && (
          <div className="absolute top-2 left-4 right-4 z-30 bg-pink-950/90 border border-pink-500/40 rounded-2xl p-2.5 flex items-center gap-2 text-pink-200 text-xs shadow-xl animate-in fade-in">
            <AlertCircle className="w-4 h-4 text-pink-400 shrink-0" />
            <span className="flex-1 text-[11px] leading-tight">{cameraError}</span>
            <button 
              onClick={() => {
                setErrorDismissed(false);
                onToggleCamera();
              }}
              className="px-2.5 py-1 rounded-xl bg-pink-600 hover:bg-pink-500 text-white font-semibold text-[10px] shrink-0"
            >
              Retry Camera
            </button>
            <button 
              onClick={() => setErrorDismissed(true)}
              className="p-1 rounded-lg hover:bg-white/10 text-white/50 hover:text-white shrink-0"
              title="Dismiss notice"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* Floating Care Action Badges (Pani, Khana, Pyar) */}
      <div className="relative z-20 flex justify-center items-center gap-2 sm:gap-3 py-1">
        <button
          onClick={() => onCareAction('water')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 hover:bg-blue-600/20 border border-white/10 hover:border-blue-500/40 text-blue-300 text-xs font-semibold transition-all hover:scale-105 active:scale-95"
        >
          <Droplets className="w-3.5 h-3.5 text-blue-400" />
          <span>Pani</span>
        </button>
        <button
          onClick={() => onCareAction('food')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 hover:bg-orange-600/20 border border-white/10 hover:border-orange-500/40 text-orange-300 text-xs font-semibold transition-all hover:scale-105 active:scale-95"
        >
          <Utensils className="w-3.5 h-3.5 text-orange-400" />
          <span>Khana</span>
        </button>
        <button
          onClick={() => onCareAction('pyaar')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 hover:bg-pink-600/20 border border-white/10 hover:border-pink-500/40 text-pink-300 text-xs font-semibold transition-all hover:scale-105 active:scale-95"
        >
          <Heart className="w-3.5 h-3.5 text-pink-400 fill-pink-400/40" />
          <span>Manao</span>
        </button>
      </div>

      {/* Bottom Video Call Control Bar */}
      <div className="relative z-30 pt-2 pb-1 flex items-center justify-center gap-4 sm:gap-6">
        
        {/* Toggle Camera */}
        <button
          onClick={onToggleCamera}
          disabled={cameraLoading}
          className={`p-3.5 rounded-2xl border transition-all active:scale-95 ${
            cameraActive 
              ? 'bg-white/10 hover:bg-white/20 border-white/20 text-pink-200' 
              : 'bg-red-500/20 hover:bg-red-500/30 border-red-500/30 text-red-300'
          }`}
          title={cameraActive ? "Turn Camera Off" : "Turn Camera On"}
        >
          {cameraLoading ? (
            <RefreshCw className="w-5 h-5 animate-spin text-pink-300" />
          ) : cameraActive ? (
            <Video className="w-5 h-5" />
          ) : (
            <VideoOff className="w-5 h-5" />
          )}
        </button>

        {/* Toggle Mic */}
        <button
          onClick={onToggleMic}
          className={`p-3.5 rounded-2xl border transition-all active:scale-95 ${
            !micMuted 
              ? 'bg-white/10 hover:bg-white/20 border-white/20 text-pink-200' 
              : 'bg-red-500/20 hover:bg-red-500/30 border-red-500/30 text-red-300'
          }`}
          title={micMuted ? "Unmute Mic" : "Mute Mic"}
        >
          {micMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>

        {/* Flip Camera (if active) */}
        {cameraActive && (
          <button
            onClick={onToggleFacingMode}
            className="p-3.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/20 text-pink-200 transition-all active:scale-95"
            title="Switch Camera (Front / Back)"
          >
            <FlipHorizontal className="w-5 h-5" />
          </button>
        )}

        {/* Screen Share Toggle */}
        {onToggleScreenShare && (
          <button
            onClick={onToggleScreenShare}
            className={`p-3.5 rounded-2xl border transition-all active:scale-95 ${
              isScreenSharing 
                ? 'bg-blue-600/30 hover:bg-blue-600/40 border-blue-500/40 text-blue-200' 
                : 'bg-white/10 hover:bg-white/20 border-white/20 text-pink-200'
            }`}
            title={isScreenSharing ? "Stop Screen Share" : "Share Screen with EZUMI"}
          >
            {isScreenSharing ? <MonitorOff className="w-5 h-5" /> : <Monitor className="w-5 h-5" />}
          </button>
        )}

        {/* End Call Button */}
        <button
          onClick={onEndCall}
          className="px-6 py-3.5 rounded-2xl bg-red-600 hover:bg-red-700 text-white font-bold tracking-wider text-xs uppercase transition-all shadow-[0_0_30px_rgba(220,38,38,0.4)] active:scale-95 flex items-center gap-2"
          title="End Video Call"
        >
          <PhoneOff className="w-5 h-5" />
          <span className="hidden sm:inline">Call Kaatein</span>
        </button>
      </div>
    </div>
  );
};
