import React, { useEffect, useState } from 'react';
import { Heart, Sparkles, Eye, Flower2 } from 'lucide-react';

interface VaniAvatarProps {
  isSpeaking: boolean;
  mood: number;
  cameraActive: boolean;
  size?: 'sm' | 'md' | 'lg' | 'full';
  aiName?: string;
}

export const VaniAvatar: React.FC<VaniAvatarProps> = ({
  isSpeaking,
  mood,
  cameraActive,
  size = 'lg',
  aiName = 'EZUMI'
}) => {
  const [blink, setBlink] = useState(false);
  const [gazeOffset, setGazeOffset] = useState({ x: 0, y: 0 });

  // Random natural eye blinking
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setBlink(true);
      setTimeout(() => setBlink(false), 180);
    }, 3800 + Math.random() * 2000);
    return () => clearInterval(blinkInterval);
  }, []);

  // Subtle natural gaze shifts like looking at the caller
  useEffect(() => {
    const gazeInterval = setInterval(() => {
      setGazeOffset({
        x: (Math.random() - 0.5) * 4,
        y: (Math.random() - 0.5) * 3,
      });
    }, 4500);
    return () => clearInterval(gazeInterval);
  }, []);

  const isUpset = mood < 40;
  const isHappy = mood >= 70;

  return (
    <div className="relative flex flex-col items-center justify-center select-none">
      {/* Dynamic Aura Glow */}
      <div 
        className={`absolute inset-0 rounded-full blur-[70px] transition-all duration-1000 ${
          isUpset 
            ? 'bg-purple-900/40' 
            : isSpeaking 
              ? 'bg-pink-500/30 scale-125' 
              : 'bg-pink-600/20'
        }`}
      />

      {/* Voice reactive wave rings */}
      {isSpeaking && (
        <>
          <div className="absolute w-72 h-72 rounded-full border border-pink-500/30 animate-ping opacity-40 pointer-events-none" />
          <div className="absolute w-84 h-84 rounded-full border border-pink-400/20 animate-pulse pointer-events-none" />
        </>
      )}

      {/* Living Portrait Canvas */}
      <div className={`relative z-10 rounded-full flex items-center justify-center p-3 transition-all duration-700 ${
        isUpset 
          ? 'ring-4 ring-purple-500/30 shadow-[0_0_50px_rgba(168,85,247,0.25)]' 
          : 'ring-4 ring-pink-500/40 shadow-[0_0_60px_rgba(236,72,153,0.35)]'
      } ${size === 'full' ? 'w-64 h-64 md:w-80 md:h-80' : size === 'lg' ? 'w-56 h-56 md:w-64 md:h-64' : 'w-40 h-40'}`}>
        
        {/* Soft atmospheric gradient skin */}
        <div className="w-full h-full rounded-full bg-gradient-to-b from-[#2a1329] via-[#1a0a1c] to-[#120614] relative overflow-hidden flex flex-col items-center justify-center border border-white/10">
          
          {/* Subtle background stars/particles */}
          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#ec4899_1px,transparent_1px)] [background-size:16px_16px]" />

          {/* Vani's Stylized Face */}
          <div className="relative z-10 flex flex-col items-center">
            
            {/* Hair Crown / Floral accessory */}
            <div className="flex items-center gap-1.5 -mb-2 z-20">
              <Flower2 className={`w-4 h-4 transition-colors duration-500 ${isUpset ? 'text-purple-400' : 'text-pink-400 animate-spin-slow'}`} />
              <div className="w-8 h-1 rounded-full bg-pink-400/40" />
              <Sparkles className="w-3.5 h-3.5 text-pink-300 animate-pulse" />
            </div>

            {/* Hair bangs silhouette */}
            <div className="w-28 h-6 bg-gradient-to-b from-purple-950 to-pink-950/80 rounded-t-full rounded-b-xl opacity-90 mb-1" />

            {/* Eyes Container */}
            <div className="flex items-center gap-7 my-2">
              {/* Left Eye */}
              <div className="relative flex flex-col items-center">
                {/* Eyebrow */}
                <div 
                  className={`w-5 h-0.5 rounded-full mb-1 transition-transform duration-500 ${
                    isUpset 
                      ? 'bg-purple-300 rotate-12 translate-y-0.5' 
                      : isHappy 
                        ? 'bg-pink-200 -rotate-6' 
                        : 'bg-pink-200/80'
                  }`} 
                />
                <div className={`w-7 h-5 rounded-full bg-[#0a020c] border border-pink-400/30 overflow-hidden flex items-center justify-center transition-all duration-150 ${
                  blink ? 'scale-y-0' : 'scale-y-100'
                }`}>
                  {/* Iris */}
                  <div 
                    className="w-4 h-4 rounded-full bg-gradient-to-b from-pink-400 to-indigo-600 relative flex items-center justify-center transition-transform duration-300"
                    style={{ transform: `translate(${gazeOffset.x}px, ${gazeOffset.y}px)` }}
                  >
                    {/* Pupil */}
                    <div className="w-2 h-2 rounded-full bg-black flex items-center justify-center">
                      <div className="w-0.5 h-0.5 rounded-full bg-white self-start ml-0.5 mt-0.5" />
                    </div>
                    {/* Sparkle reflection */}
                    <div className="absolute top-0.5 right-0.5 w-1 h-1 rounded-full bg-white/90" />
                  </div>
                </div>
              </div>

              {/* Right Eye */}
              <div className="relative flex flex-col items-center">
                {/* Eyebrow */}
                <div 
                  className={`w-5 h-0.5 rounded-full mb-1 transition-transform duration-500 ${
                    isUpset 
                      ? 'bg-purple-300 -rotate-12 translate-y-0.5' 
                      : isHappy 
                        ? 'bg-pink-200 rotate-6' 
                        : 'bg-pink-200/80'
                  }`} 
                />
                <div className={`w-7 h-5 rounded-full bg-[#0a020c] border border-pink-400/30 overflow-hidden flex items-center justify-center transition-all duration-150 ${
                  blink ? 'scale-y-0' : 'scale-y-100'
                }`}>
                  {/* Iris */}
                  <div 
                    className="w-4 h-4 rounded-full bg-gradient-to-b from-pink-400 to-indigo-600 relative flex items-center justify-center transition-transform duration-300"
                    style={{ transform: `translate(${gazeOffset.x}px, ${gazeOffset.y}px)` }}
                  >
                    {/* Pupil */}
                    <div className="w-2 h-2 rounded-full bg-black flex items-center justify-center">
                      <div className="w-0.5 h-0.5 rounded-full bg-white self-start ml-0.5 mt-0.5" />
                    </div>
                    {/* Sparkle reflection */}
                    <div className="absolute top-0.5 right-0.5 w-1 h-1 rounded-full bg-white/90" />
                  </div>
                </div>
              </div>
            </div>

            {/* Cheeks & Blush */}
            <div className="w-24 flex justify-between items-center px-1 my-0.5">
              <div className={`w-3.5 h-1.5 rounded-full blur-[2px] transition-all duration-500 ${
                isUpset ? 'bg-purple-500/40' : isHappy ? 'bg-pink-400/70 scale-125' : 'bg-pink-400/40'
              }`} />
              {/* Cute nose dot */}
              <div className="w-1 h-1 rounded-full bg-pink-300/30" />
              <div className={`w-3.5 h-1.5 rounded-full blur-[2px] transition-all duration-500 ${
                isUpset ? 'bg-purple-500/40' : isHappy ? 'bg-pink-400/70 scale-125' : 'bg-pink-400/40'
              }`} />
            </div>

            {/* Mouth / Expressions with Speaking animation */}
            <div className="h-5 flex items-center justify-center mt-1">
              {isSpeaking ? (
                <div className="flex items-center gap-0.5">
                  <span className="w-1.5 h-2.5 bg-pink-300 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-2 h-4 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '120ms' }} />
                  <span className="w-2.5 h-3 bg-pink-300 rounded-full animate-bounce" style={{ animationDelay: '240ms' }} />
                  <span className="w-1.5 h-2 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '360ms' }} />
                </div>
              ) : isUpset ? (
                // Upset pout
                <div className="w-4 h-1.5 border-t-2 border-purple-300 rounded-t-full mt-1" />
              ) : isHappy ? (
                // Sweet smile
                <div className="w-5 h-2 border-b-2 border-pink-300 rounded-b-full" />
              ) : (
                // Gentle relaxed lips
                <div className="w-3.5 h-0.5 bg-pink-300/80 rounded-full" />
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Floating Status Indicator */}
      <div className="mt-4 flex items-center gap-2">
        {cameraActive && (
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-pink-950/80 border border-pink-500/40 text-pink-200 text-[10px] font-semibold tracking-wider shadow-lg backdrop-blur-md animate-pulse">
            <Eye className="w-3 h-3 text-pink-400" />
            <span>{aiName} can see you</span>
          </div>
        )}
        <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-semibold tracking-wider shadow-lg backdrop-blur-md ${
          isUpset 
            ? 'bg-purple-950/80 border border-purple-500/40 text-purple-200' 
            : 'bg-white/5 border border-white/10 text-pink-200/80'
        }`}>
          <Heart className={`w-2.5 h-2.5 ${isUpset ? 'text-purple-400' : 'text-pink-400 fill-pink-400'}`} />
          <span>{isUpset ? 'Feeling Sensitive' : isSpeaking ? 'Speaking with you' : 'Listening...'}</span>
        </div>
      </div>
    </div>
  );
};
