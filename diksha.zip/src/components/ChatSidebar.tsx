import React from 'react';
import { 
  Plus, MessageSquare, History, Settings, Shield, 
  Terminal, FileText, Globe, Smartphone, Video,
  LogOut, LogIn, User as UserIcon, Database, Mic, MicOff,
  ChevronLeft, Trash2, Heart
} from 'lucide-react';
import { TranscriptionTurn } from '../../types';

interface ChatSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onNewChat: () => void;
  turns: TranscriptionTurn[];
  onOpenNotes: () => void;
  onOpenTasks: () => void;
  onOpenResearch: () => void;
  onOpenDevice: () => void;
  onOpenVideoCall: () => void;
  onOpenSettings: () => void;
  wakeWordEnabled: boolean;
  onToggleWakeWord: () => void;
  user: any;
  onLogin: () => void;
  onLogout: () => void;
  dbSyncStatus: 'synced' | 'local' | 'syncing';
}

export const ChatSidebar: React.FC<ChatSidebarProps> = ({
  isOpen,
  onClose,
  onNewChat,
  turns,
  onOpenNotes,
  onOpenTasks,
  onOpenResearch,
  onOpenDevice,
  onOpenVideoCall,
  onOpenSettings,
  wakeWordEnabled,
  onToggleWakeWord,
  user,
  onLogin,
  onLogout,
  dbSyncStatus,
}) => {
  // Extract topic snippets from turns
  const userTurns = turns.filter((t) => t.role === 'user');
  const recentTopics = userTurns.slice(-8).reverse();

  return (
    <>
      {/* Mobile/Tablet backdrop overlay */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 w-72 bg-[#000000] border-r border-[#1F1F1F] flex flex-col transition-transform duration-300 ease-in-out lg:static lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Top Header & New Chat */}
        <div className="p-4 border-b border-[#1A1A1A] space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-[#141414] border border-[#2B2B2B] flex items-center justify-center">
                <span className="font-bold text-sm tracking-widest text-white">EZ</span>
              </div>
              <div>
                <h1 className="text-sm font-bold tracking-tight text-white flex items-center gap-1.5">
                  EZUMI
                  <span className="text-[9px] uppercase px-1.5 py-0.2 rounded bg-[#1F1F1F] text-[#A0A0A0] border border-[#2F2F2F]">
                    AI
                  </span>
                </h1>
                <p className="text-[10px] text-[#707070]">Personal Voice & Vision</p>
              </div>
            </div>

            <button
              onClick={onClose}
              aria-label="Collapse sidebar"
              className="p-1 rounded-lg text-[#707070] hover:text-white hover:bg-[#141414] transition-colors lg:hidden"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          </div>

          {/* New Chat Button */}
          <button
            onClick={() => {
              onNewChat();
              if (window.innerWidth < 1024) onClose();
            }}
            className="w-full py-2.5 px-3 rounded-xl bg-[#121212] hover:bg-[#1A1A1A] border border-[#262626] hover:border-[#383838] text-white text-xs font-semibold flex items-center justify-center gap-2 transition-all active:scale-95 shadow-sm"
          >
            <Plus className="w-4 h-4 text-white" />
            <span>New Conversation</span>
          </button>
        </div>

        {/* Scrollable Center: Navigation & History */}
        <div className="flex-1 overflow-y-auto p-3 space-y-5 text-xs text-[#A0A0A0]">
          
          {/* EZUMI Core Subsystems */}
          <div>
            <div className="text-[10px] uppercase font-bold tracking-wider text-[#606060] px-2 mb-1.5">
              Capabilities & Tools
            </div>
            <div className="space-y-1">
              <button
                onClick={() => {
                  onOpenVideoCall();
                  if (window.innerWidth < 1024) onClose();
                }}
                className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[#121212] text-[#D0D0D0] hover:text-white transition-colors text-left"
              >
                <Video className="w-4 h-4 text-emerald-400" />
                <span>Face-to-Face Video Call</span>
              </button>

              <button
                onClick={() => {
                  onOpenResearch();
                  if (window.innerWidth < 1024) onClose();
                }}
                className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[#121212] text-[#D0D0D0] hover:text-white transition-colors text-left"
              >
                <Globe className="w-4 h-4 text-blue-400" />
                <span>Web Research & News</span>
              </button>

              <button
                onClick={() => {
                  onOpenTasks();
                  if (window.innerWidth < 1024) onClose();
                }}
                className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[#121212] text-[#D0D0D0] hover:text-white transition-colors text-left"
              >
                <Terminal className="w-4 h-4 text-purple-400" />
                <span>Autonomous Tasks Engine</span>
              </button>

              <button
                onClick={() => {
                  onOpenNotes();
                  if (window.innerWidth < 1024) onClose();
                }}
                className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[#121212] text-[#D0D0D0] hover:text-white transition-colors text-left"
              >
                <FileText className="w-4 h-4 text-amber-400" />
                <span>Smart Voice Notepad</span>
              </button>

              <button
                onClick={() => {
                  onOpenDevice();
                  if (window.innerWidth < 1024) onClose();
                }}
                className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[#121212] text-[#D0D0D0] hover:text-white transition-colors text-left"
              >
                <Smartphone className="w-4 h-4 text-teal-400" />
                <span>Calls & WhatsApp Hub</span>
              </button>
            </div>
          </div>

          {/* Wake Word Status Quick Toggle */}
          <div className="px-2 py-2 rounded-xl bg-[#0D0D0D] border border-[#1F1F1F]">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[11px] font-semibold text-white flex items-center gap-1.5">
                <Mic className="w-3.5 h-3.5 text-emerald-400" />
                Wake Word "Ezumi"
              </span>
              <button
                onClick={onToggleWakeWord}
                className={`text-[10px] px-2 py-0.5 rounded-full font-bold transition-all ${
                  wakeWordEnabled
                    ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700/60'
                    : 'bg-[#1C1C1C] text-[#808080] border border-[#2C2C2C]'
                }`}
              >
                {wakeWordEnabled ? 'Active' : 'Off'}
              </button>
            </div>
            <p className="text-[10px] text-[#707070]">
              {wakeWordEnabled ? 'Listening hands-free in background' : 'Click to enable voice wake'}
            </p>
          </div>

          {/* Recent Memory History */}
          <div>
            <div className="flex items-center justify-between px-2 mb-1.5">
              <span className="text-[10px] uppercase font-bold tracking-wider text-[#606060]">
                Recent Inquiries ({turns.length})
              </span>
              <span className="text-[9px] text-[#707070] flex items-center gap-1">
                <Database className="w-2.5 h-2.5" />
                {dbSyncStatus === 'synced' ? 'Cloud SQL' : 'Local'}
              </span>
            </div>

            <div className="space-y-1">
              {recentTopics.length === 0 ? (
                <div className="px-2 py-3 text-[11px] text-[#555555] italic">
                  No conversation history yet. Start speaking or typing!
                </div>
              ) : (
                recentTopics.map((turn, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-[#121212] text-[#909090] hover:text-white transition-colors cursor-pointer group"
                    title={turn.text}
                  >
                    <MessageSquare className="w-3.5 h-3.5 shrink-0 text-[#606060] group-hover:text-white" />
                    <span className="truncate text-xs">{turn.text}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Bottom User Profile & Settings */}
        <div className="p-3 border-t border-[#1A1A1A] space-y-2 bg-[#050505]">
          {/* User Sign-in row */}
          <div className="flex items-center justify-between px-2 py-1.5 rounded-lg bg-[#0F0F0F] border border-[#1C1C1C]">
            <div className="flex items-center gap-2 truncate">
              {user && user.photoURL ? (
                <img src={user.photoURL} alt="Profile" className="w-5 h-5 rounded-full shrink-0" />
              ) : (
                <UserIcon className="w-4 h-4 text-[#808080] shrink-0" />
              )}
              <div className="truncate text-xs text-white">
                {user ? user.displayName || user.email || 'Cloud User' : 'Guest (Local)'}
              </div>
            </div>

            {user ? (
              <button
                onClick={onLogout}
                title="Log out"
                className="p-1 text-[#707070] hover:text-red-400 transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                onClick={onLogin}
                className="text-[10px] font-semibold text-white px-2 py-0.5 rounded bg-[#1F1F1F] hover:bg-[#2A2A2A] border border-[#333333] transition-colors"
              >
                Sign In
              </button>
            )}
          </div>

          {/* Settings Trigger */}
          <button
            onClick={() => {
              onOpenSettings();
              if (window.innerWidth < 1024) onClose();
            }}
            className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg hover:bg-[#121212] text-[#A0A0A0] hover:text-white text-xs transition-colors"
          >
            <Settings className="w-4 h-4" />
            <span>Settings & Preferences</span>
          </button>
        </div>
      </aside>
    </>
  );
};
