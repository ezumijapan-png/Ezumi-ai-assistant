import React, { useState, useEffect } from 'react';
import { 
  Globe, Newspaper, Search, ExternalLink, Volume2, 
  Sparkles, X, Loader2, ArrowRight, ShieldCheck, Calendar 
} from 'lucide-react';

interface ResearchSource {
  title: string;
  url: string;
}

interface NewsStory {
  headline: string;
  summary: string;
  source: string;
  publishedDate?: string;
  category: string;
}

interface WebResearchNewsModalProps {
  isOpen: boolean;
  onClose: () => void;
  token: string | null;
  onSpeakText?: (text: string) => void;
  initialQuery?: string;
  initialMode?: 'search' | 'news';
}

export const WebResearchNewsModal: React.FC<WebResearchNewsModalProps> = ({
  isOpen,
  onClose,
  token,
  onSpeakText,
  initialQuery = '',
  initialMode = 'search',
}) => {
  const [mode, setMode] = useState<'search' | 'news'>(initialMode);
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [searching, setSearching] = useState(false);
  const [searchResult, setSearchResult] = useState<{
    summary: string;
    sources: ResearchSource[];
    spokenBrief: string;
  } | null>(null);

  const [newsLoading, setNewsLoading] = useState(false);
  const [newsStories, setNewsStories] = useState<NewsStory[]>([]);
  const [newsAudioScript, setNewsAudioScript] = useState('');
  const [newsCategory, setNewsCategory] = useState('Technology & AI');

  useEffect(() => {
    if (initialQuery) {
      setSearchQuery(initialQuery);
      handleSearch(initialQuery);
    }
  }, [initialQuery]);

  useEffect(() => {
    if (isOpen && mode === 'news' && newsStories.length === 0) {
      fetchNews(newsCategory);
    }
  }, [isOpen, mode]);

  const handleSearch = async (q?: string) => {
    const targetQuery = q || searchQuery;
    if (!targetQuery.trim()) return;
    setSearching(true);
    setSearchResult(null);
    try {
      const res = await fetch('/api/ai/research', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ query: targetQuery.trim() }),
      });
      if (res.ok) {
        const data = await res.json();
        setSearchResult({
          summary: data.summary,
          sources: data.sources || [],
          spokenBrief: data.spokenBrief || '',
        });
      }
    } catch (e) {
      console.error('Search error:', e);
    } finally {
      setSearching(false);
    }
  };

  const fetchNews = async (cat: string) => {
    setNewsLoading(true);
    setNewsCategory(cat);
    try {
      const res = await fetch(`/api/ai/news?category=${encodeURIComponent(cat)}`);
      if (res.ok) {
        const data = await res.json();
        setNewsStories(data.stories || []);
        setNewsAudioScript(data.spokenAudioScript || '');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setNewsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xl flex items-center justify-center p-4">
      <div className="w-full max-w-3xl bg-[#0a0815] border border-blue-500/30 rounded-[2rem] p-5 md:p-6 shadow-[0_0_80px_rgba(59,130,246,0.2)] flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-blue-300">
              {mode === 'search' ? <Globe className="w-5 h-5" /> : <Newspaper className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                {mode === 'search' ? 'EZUMI Internet Research' : 'EZUMI Live News Reader'}
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 font-semibold">
                  Google Search Grounded
                </span>
              </h2>
              <p className="text-xs text-white/50">
                {mode === 'search' ? 'Real-time sources, freshness evaluation, aur evidence-based answers' : 'Current date verification, reliable sources, aur audio speech summary'}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-white/50 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector */}
        <div className="flex gap-2 my-3">
          <button
            onClick={() => setMode('search')}
            className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              mode === 'search' 
                ? 'bg-blue-600 text-white shadow-md' 
                : 'bg-white/5 text-white/60 hover:text-white'
            }`}
          >
            <Search className="w-3.5 h-3.5" />
            <span>Web Research</span>
          </button>
          <button
            onClick={() => setMode('news')}
            className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              mode === 'news' 
                ? 'bg-blue-600 text-white shadow-md' 
                : 'bg-white/5 text-white/60 hover:text-white'
            }`}
          >
            <Newspaper className="w-3.5 h-3.5" />
            <span>Daily News Briefing</span>
          </button>
        </div>

        {mode === 'search' ? (
          /* Web Research View */
          <div className="flex-1 flex flex-col overflow-hidden min-h-[340px]">
            {/* Search Input Bar */}
            <div className="flex gap-2 mb-4">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Google par kya search karna hai? (e.g. 'Latest Gemini 3.8 features', 'Nvidia AI news')..."
                className="flex-1 bg-white/5 border border-white/10 rounded-2xl px-4 py-2.5 text-xs text-white placeholder:text-white/30 focus:outline-none focus:border-blue-500/50"
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              />
              <button
                onClick={() => handleSearch()}
                disabled={searching || !searchQuery.trim()}
                className="px-5 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-md active:scale-95 disabled:opacity-50"
              >
                {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                <span>Search</span>
              </button>
            </div>

            {/* Results container */}
            <div className="flex-1 overflow-y-auto space-y-4 pr-1">
              {searching ? (
                <div className="py-16 flex flex-col items-center justify-center gap-3 text-white/50 text-xs">
                  <Loader2 className="w-8 h-8 animate-spin text-blue-400" />
                  <span>Internet par sources search kiye jaa rahe hain...</span>
                </div>
              ) : searchResult ? (
                <div className="space-y-4">
                  
                  {/* Synthesis Summary */}
                  <div className="p-4 rounded-2xl bg-black/40 border border-blue-500/20">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] uppercase font-bold tracking-widest text-blue-300 flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-blue-400" /> Grounded Research Summary
                      </span>
                      {onSpeakText && searchResult.spokenBrief && (
                        <button
                          onClick={() => onSpeakText(searchResult.spokenBrief)}
                          className="px-2.5 py-1 rounded-xl bg-blue-600/30 hover:bg-blue-600/50 text-blue-200 border border-blue-500/30 text-[10px] font-bold flex items-center gap-1 transition-all"
                          title="Read summary aloud"
                        >
                          <Volume2 className="w-3 h-3" />
                          <span>Sunayein</span>
                        </button>
                      )}
                    </div>
                    <p className="text-xs text-blue-50/90 leading-relaxed whitespace-pre-line">
                      {searchResult.summary}
                    </p>
                  </div>

                  {/* Sources List */}
                  {searchResult.sources.length > 0 && (
                    <div>
                      <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest block mb-2">
                        Verified Sources ({searchResult.sources.length})
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {searchResult.sources.map((s, idx) => (
                          <a
                            key={idx}
                            href={s.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-white/80 hover:text-white transition-all flex items-center justify-between group"
                          >
                            <span className="truncate pr-2 font-medium">{s.title}</span>
                            <ExternalLink className="w-3.5 h-3.5 text-white/40 group-hover:text-blue-400 shrink-0" />
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-16 text-white/30 text-xs italic">
                  Koi search query dalein ya voice se kahein: "Ezumi, search Google for..."
                </div>
              )}
            </div>
          </div>
        ) : (
          /* News Reader View */
          <div className="flex-1 flex flex-col overflow-hidden min-h-[340px]">
            {/* Category pills & Read Aloud action */}
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-white/10">
              <div className="flex gap-1.5 overflow-x-auto">
                {['Technology & AI', 'India Headlines', 'World News', 'Science & Innovation'].map(c => (
                  <button
                    key={c}
                    onClick={() => fetchNews(c)}
                    className={`px-3 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap transition-all ${
                      newsCategory === c 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-white/5 text-white/60 hover:text-white'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>

              {newsAudioScript && onSpeakText && (
                <button
                  onClick={() => onSpeakText(newsAudioScript)}
                  className="px-3.5 py-1.5 rounded-full bg-pink-600 hover:bg-pink-500 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-md active:scale-95 shrink-0 ml-2"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Khabrein Sunayein</span>
                </button>
              )}
            </div>

            {/* News List */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1">
              {newsLoading ? (
                <div className="py-16 flex flex-col items-center justify-center gap-3 text-white/50 text-xs">
                  <Loader2 className="w-8 h-8 animate-spin text-blue-400" />
                  <span>Taza samachar fetch kiye jaa rahe hain...</span>
                </div>
              ) : newsStories.length === 0 ? (
                <div className="text-center py-16 text-white/30 text-xs italic">
                  Khabrein load karne ke liye category select karein.
                </div>
              ) : (
                newsStories.map((story, idx) => (
                  <div key={idx} className="p-3.5 rounded-2xl bg-white/5 border border-white/10 hover:border-white/20 transition-all">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                        {story.source}
                      </span>
                      {story.publishedDate && (
                        <span className="text-[10px] text-white/40 flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {story.publishedDate}
                        </span>
                      )}
                    </div>
                    <h4 className="font-bold text-sm text-white mb-1">{story.headline}</h4>
                    <p className="text-xs text-white/60 leading-relaxed">{story.summary}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
