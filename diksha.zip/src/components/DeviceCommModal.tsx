import React, { useState } from 'react';
import { 
  Phone, MessageSquare, ExternalLink, ShieldCheck, 
  X, Check, Smartphone, Monitor, Camera, Mic, AlertCircle 
} from 'lucide-react';

interface DeviceCommModalProps {
  isOpen: boolean;
  onClose: () => void;
  token: string | null;
  onStartScreenShare?: () => void;
  isScreenSharing?: boolean;
}

export const DeviceCommModal: React.FC<DeviceCommModalProps> = ({
  isOpen,
  onClose,
  token,
  onStartScreenShare,
  isScreenSharing = false,
}) => {
  const [activeTab, setActiveTab] = useState<'phone' | 'whatsapp' | 'device'>('phone');
  
  // Phone calling state
  const [contactName, setContactName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [callIntent, setCallIntent] = useState<{ dialerUri: string; prompt: string } | null>(null);

  // WhatsApp state
  const [waRecipient, setWaRecipient] = useState('');
  const [waPhone, setWaPhone] = useState('');
  const [waMessage, setWaMessage] = useState('');
  const [waDraft, setWaDraft] = useState<{ webUrl: string } | null>(null);

  const handlePrepareCall = async () => {
    if (!contactName.trim()) return;
    try {
      const res = await fetch('/api/device/call', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ contactName, phoneNumber }),
      });
      if (res.ok) {
        const data = await res.json();
        setCallIntent({
          dialerUri: data.dialerUri,
          prompt: data.prompt,
        });
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handlePrepareWhatsApp = async () => {
    if (!waPhone.trim() || !waMessage.trim()) return;
    try {
      const res = await fetch('/api/device/whatsapp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          contactName: waRecipient || 'Contact',
          phoneNumber: waPhone,
          messageText: waMessage,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setWaDraft({ webUrl: data.webUrl });
      }
    } catch (e) {
      console.error(e);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xl flex items-center justify-center p-4">
      <div className="w-full max-w-xl bg-[#0e0717] border border-emerald-500/30 rounded-[2rem] p-5 md:p-6 shadow-[0_0_80px_rgba(16,185,129,0.2)] flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-300">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                EZUMI Device & Calling Hub
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold">
                  Authorized Integrations
                </span>
              </h2>
              <p className="text-xs text-white/50">Phone calls, WhatsApp drafts, aur screen share controls</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-white/50 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex gap-2 my-3">
          <button
            onClick={() => setActiveTab('phone')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'phone' 
                ? 'bg-emerald-600 text-white shadow-md' 
                : 'bg-white/5 text-white/60 hover:text-white'
            }`}
          >
            <Phone className="w-3.5 h-3.5" />
            <span>Phone Call</span>
          </button>
          <button
            onClick={() => setActiveTab('whatsapp')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'whatsapp' 
                ? 'bg-emerald-600 text-white shadow-md' 
                : 'bg-white/5 text-white/60 hover:text-white'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>WhatsApp Draft</span>
          </button>
          <button
            onClick={() => setActiveTab('device')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'device' 
                ? 'bg-emerald-600 text-white shadow-md' 
                : 'bg-white/5 text-white/60 hover:text-white'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Device Status</span>
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto space-y-4 py-2">
          {activeTab === 'phone' && (
            <div className="space-y-3">
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-xs text-white/70">
                EZUMI system dialer ke zariye verified phone call initiate karegi. Platform security policy ke mutabik koi bhi secret background call nahi lagti.
              </div>

              <div>
                <label className="text-[11px] font-bold text-white/60 block mb-1">Contact Name</label>
                <input
                  type="text"
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  placeholder="e.g. Rahul, Maa, Office"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white placeholder:text-white/30 focus:outline-none focus:border-emerald-500/50"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-white/60 block mb-1">Phone Number</label>
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="e.g. +919876543210"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white placeholder:text-white/30 focus:outline-none focus:border-emerald-500/50"
                />
              </div>

              <button
                onClick={handlePrepareCall}
                disabled={!contactName.trim()}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md active:scale-95 disabled:opacity-50"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call Intent Prepare Karein</span>
              </button>

              {callIntent && (
                <div className="mt-3 p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-center animate-in fade-in">
                  <p className="text-xs text-emerald-200 mb-3">{callIntent.prompt}</p>
                  {callIntent.dialerUri ? (
                    <a
                      href={callIntent.dialerUri}
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg active:scale-95 transition-all"
                    >
                      <Phone className="w-4 h-4" />
                      <span>Phone Dialer Kholein</span>
                    </a>
                  ) : (
                    <p className="text-xs text-red-300">Number darj karein dialer kholne ke liye.</p>
                  )}
                </div>
              )}
            </div>
          )}

          {activeTab === 'whatsapp' && (
            <div className="space-y-3">
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-xs text-white/70">
                EZUMI message draft prepare karti hai jise aap official WhatsApp Web ya App mein verify karke bhej sakte hain.
              </div>

              <div>
                <label className="text-[11px] font-bold text-white/60 block mb-1">WhatsApp Number (with Country Code)</label>
                <input
                  type="tel"
                  value={waPhone}
                  onChange={(e) => setWaPhone(e.target.value)}
                  placeholder="e.g. 919876543210"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white placeholder:text-white/30 focus:outline-none focus:border-emerald-500/50"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-white/60 block mb-1">Message Content</label>
                <textarea
                  value={waMessage}
                  onChange={(e) => setWaMessage(e.target.value)}
                  placeholder="Khabar ya message yahan likhein ya voice se kahein..."
                  rows={3}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white placeholder:text-white/30 focus:outline-none focus:border-emerald-500/50 resize-none font-sans"
                />
              </div>

              <button
                onClick={handlePrepareWhatsApp}
                disabled={!waPhone.trim() || !waMessage.trim()}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md active:scale-95 disabled:opacity-50"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>WhatsApp Draft Verify Karein</span>
              </button>

              {waDraft && (
                <div className="mt-3 p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-center animate-in fade-in">
                  <p className="text-xs text-emerald-200 mb-3 font-medium">
                    Draft taiyyar hai! Niche click karke WhatsApp par bhein:
                  </p>
                  <a
                    href={waDraft.webUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg active:scale-95 transition-all"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>WhatsApp par Send Karein</span>
                  </a>
                </div>
              )}
            </div>
          )}

          {activeTab === 'device' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2.5">
                <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-2.5">
                  <Mic className="w-4 h-4 text-emerald-400" />
                  <div>
                    <span className="text-xs font-bold text-white block">Microphone</span>
                    <span className="text-[10px] text-emerald-300">Active & Permitted</span>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-2.5">
                  <Camera className="w-4 h-4 text-emerald-400" />
                  <div>
                    <span className="text-xs font-bold text-white block">Camera</span>
                    <span className="text-[10px] text-emerald-300">Face-to-Face Ready</span>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-2.5">
                  <Monitor className="w-4 h-4 text-blue-400" />
                  <div>
                    <span className="text-xs font-bold text-white block">Screen Access</span>
                    <span className="text-[10px] text-blue-300">{isScreenSharing ? 'Active' : 'On Demand'}</span>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-2.5">
                  <Smartphone className="w-4 h-4 text-purple-400" />
                  <div>
                    <span className="text-xs font-bold text-white block">Platform Dial</span>
                    <span className="text-[10px] text-purple-300">Intent Handler</span>
                  </div>
                </div>
              </div>

              {onStartScreenShare && (
                <div className="mt-4 p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-white">Live Screen Share with EZUMI</h4>
                    <p className="text-[11px] text-white/50">Apni window ya screen EZUMI ko dikhakar madad lein</p>
                  </div>
                  <button
                    onClick={onStartScreenShare}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all active:scale-95 ${
                      isScreenSharing 
                        ? 'bg-red-600 hover:bg-red-700 text-white' 
                        : 'bg-blue-600 hover:bg-blue-500 text-white'
                    }`}
                  >
                    {isScreenSharing ? 'Stop Screen Share' : 'Share Screen'}
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
