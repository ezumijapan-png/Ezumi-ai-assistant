import React, { useState, useEffect } from 'react';
import { 
  FileText, Mic, MicOff, Plus, Trash2, Download, 
  Save, Check, Loader2, X, Sparkles, Tag, Volume2 
} from 'lucide-react';

interface Note {
  id: number;
  title: string;
  content: string;
  tags?: string;
  createdAt: string;
  updatedAt: string;
}

interface SmartNotepadModalProps {
  isOpen: boolean;
  onClose: () => void;
  token: string | null;
  onSpeakText?: (text: string) => void;
}

export const SmartNotepadModal: React.FC<SmartNotepadModalProps> = ({
  isOpen,
  onClose,
  token,
  onSpeakText,
}) => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [activeNote, setActiveNote] = useState<Note | null>(null);
  const [isDictating, setIsDictating] = useState(false);
  const [dictationTranscript, setDictationTranscript] = useState('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Load notes
  const fetchNotes = async () => {
    if (!token) {
      // Local fallback
      const saved = localStorage.getItem('ezumi_notes');
      if (saved) {
        try { setNotes(JSON.parse(saved)); } catch (e) {}
      }
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/notes', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setNotes(data.notes || []);
        if (data.notes?.length && !activeNote) {
          setActiveNote(data.notes[0]);
        }
      }
    } catch (err) {
      console.error('Failed to fetch notes:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchNotes();
    }
  }, [isOpen, token]);

  // Speech Recognition for continuous dictation
  useEffect(() => {
    let recognition: any = null;
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (isDictating && SpeechRec) {
      recognition = new SpeechRec();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'hi-IN'; // accepts Hinglish / English / Hindi

      recognition.onresult = (event: any) => {
        let finalChunk = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalChunk += transcript + ' ';
          }
        }

        if (finalChunk) {
          setActiveNote(prev => {
            if (!prev) {
              const newN: Note = {
                id: Date.now(),
                title: `Voice Note - ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
                content: finalChunk.trim(),
                tags: 'dictation',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
              };
              return newN;
            }
            return {
              ...prev,
              content: prev.content ? `${prev.content}\n${finalChunk.trim()}` : finalChunk.trim(),
              updatedAt: new Date().toISOString(),
            };
          });
        }
      };

      recognition.onerror = (err: any) => {
        console.error('Dictation error:', err);
        setIsDictating(false);
      };

      recognition.onend = () => {
        if (isDictating) {
          try { recognition.start(); } catch (e) {}
        }
      };

      try {
        recognition.start();
      } catch (e) {
        console.error('Failed to start recognition:', e);
      }
    }

    return () => {
      if (recognition) {
        recognition.stop();
      }
    };
  }, [isDictating]);

  const handleCreateNote = async () => {
    const newNoteObj: Note = {
      id: Date.now(),
      title: `Note #${notes.length + 1} - ${new Date().toLocaleDateString()}`,
      content: '',
      tags: 'smart-notes',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    if (token) {
      try {
        const res = await fetch('/api/notes', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            title: newNoteObj.title,
            content: newNoteObj.content,
            tags: newNoteObj.tags,
          }),
        });
        if (res.ok) {
          const data = await res.json();
          setNotes(prev => [data.note, ...prev]);
          setActiveNote(data.note);
          return;
        }
      } catch (e) {}
    }

    setNotes(prev => [newNoteObj, ...prev]);
    setActiveNote(newNoteObj);
    localStorage.setItem('ezumi_notes', JSON.stringify([newNoteObj, ...notes]));
  };

  const handleSaveActiveNote = async () => {
    if (!activeNote) return;
    setSaving(true);
    if (token && activeNote.id) {
      try {
        await fetch(`/api/notes/${activeNote.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            title: activeNote.title,
            content: activeNote.content,
            tags: activeNote.tags,
          }),
        });
      } catch (e) {
        console.error('Save failed:', e);
      }
    }
    // Update local state
    setNotes(prev => prev.map(n => n.id === activeNote.id ? activeNote : n));
    localStorage.setItem('ezumi_notes', JSON.stringify(notes));
    setSaving(false);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const handleDeleteNote = async (id: number) => {
    if (token) {
      try {
        await fetch(`/api/notes/${id}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}` },
        });
      } catch (e) {}
    }
    const filtered = notes.filter(n => n.id !== id);
    setNotes(filtered);
    localStorage.setItem('ezumi_notes', JSON.stringify(filtered));
    if (activeNote?.id === id) {
      setActiveNote(filtered[0] || null);
    }
  };

  const handleExport = () => {
    if (!activeNote) return;
    const blob = new Blob([activeNote.content], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${activeNote.title.replace(/[^a-zA-Z0-9]/g, '_')}.md`;
    link.click();
    URL.revokeObjectURL(url);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xl flex items-center justify-center p-4">
      <div className="w-full max-w-3xl bg-[#110614] border border-pink-500/30 rounded-[2rem] p-5 md:p-6 shadow-[0_0_80px_rgba(236,72,153,0.2)] flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-pink-500/20 border border-pink-500/30 flex items-center justify-center text-pink-300">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                EZUMI Smart Voice Notepad
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold">
                  Continuous Dictation
                </span>
              </h2>
              <p className="text-xs text-white/50">Aap bolte jaiye, EZUMI lagatar notes likhti jayegi</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-white/50 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Grid: Left Sidebar (List) + Right Editor */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4 my-4 overflow-hidden min-h-[360px]">
          
          {/* Notes Sidebar */}
          <div className="md:col-span-1 border border-white/10 rounded-2xl p-3 bg-black/30 flex flex-col overflow-hidden">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-white/60 tracking-wider uppercase">Saved Notes ({notes.length})</span>
              <button
                onClick={handleCreateNote}
                className="p-1.5 rounded-xl bg-pink-600/30 hover:bg-pink-600/50 text-pink-200 border border-pink-500/30 transition-all flex items-center gap-1 text-[11px] font-bold"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Naya</span>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {loading ? (
                <div className="py-8 flex justify-center"><Loader2 className="w-5 h-5 animate-spin text-pink-400" /></div>
              ) : notes.length === 0 ? (
                <div className="text-center py-10 text-white/30 text-xs italic">
                  Koi notes nahi hain. "Naya" dabayein ya mic on karke bole!
                </div>
              ) : (
                notes.map(n => (
                  <div
                    key={n.id}
                    onClick={() => setActiveNote(n)}
                    className={`p-2.5 rounded-xl cursor-pointer transition-all border ${
                      activeNote?.id === n.id 
                        ? 'bg-pink-950/60 border-pink-500/40 text-pink-100 shadow-md' 
                        : 'bg-white/5 border-transparent text-white/60 hover:bg-white/10 hover:text-white'
                    }`}
                  >
                    <div className="font-semibold text-xs truncate">{n.title || 'Untitled Note'}</div>
                    <div className="text-[10px] text-white/40 truncate mt-0.5">{n.content || '(Khali note)'}</div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Active Note Editor */}
          <div className="md:col-span-2 border border-white/10 rounded-2xl p-4 bg-black/40 flex flex-col justify-between overflow-hidden">
            {activeNote ? (
              <div className="flex-1 flex flex-col overflow-hidden">
                {/* Note Title Input */}
                <input
                  type="text"
                  value={activeNote.title}
                  onChange={(e) => setActiveNote({ ...activeNote, title: e.target.value })}
                  placeholder="Note ka Title..."
                  className="w-full bg-transparent text-white font-bold text-base pb-2 mb-2 border-b border-white/10 focus:outline-none focus:border-pink-500/50 transition-colors"
                />

                {/* Dictation Status Banner */}
                {isDictating && (
                  <div className="mb-2 px-3 py-1.5 rounded-xl bg-pink-950/80 border border-pink-500/40 text-pink-200 text-xs flex items-center gap-2 animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                    <span className="font-bold">Live Listening...</span>
                    <span className="text-white/60 text-[11px]">Aap bolte jaiye, automatically type hota rahega</span>
                  </div>
                )}

                {/* Content Textarea */}
                <textarea
                  value={activeNote.content}
                  onChange={(e) => setActiveNote({ ...activeNote, content: e.target.value })}
                  placeholder="Yahan notes likhein ya 'Mic' on karke bolna shuru karein..."
                  className="flex-1 w-full bg-transparent text-pink-50/90 text-sm leading-relaxed resize-none focus:outline-none font-mono placeholder:text-white/20 overflow-y-auto"
                />

                {/* Action Bar */}
                <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {/* Live Dictation Toggle */}
                    <button
                      onClick={() => setIsDictating(!isDictating)}
                      className={`px-3.5 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all shadow-md active:scale-95 ${
                        isDictating 
                          ? 'bg-red-600 hover:bg-red-700 text-white animate-pulse' 
                          : 'bg-pink-600 hover:bg-pink-500 text-white'
                      }`}
                    >
                      {isDictating ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                      <span>{isDictating ? 'Dictation Rokein' : 'Bolkar Likhna Shuru Karein'}</span>
                    </button>

                    {/* Read Aloud */}
                    {activeNote.content && onSpeakText && (
                      <button
                        onClick={() => onSpeakText(activeNote.content)}
                        className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-white/70 hover:text-white border border-white/10 transition-all"
                        title="Read Note Aloud"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleExport}
                      className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-white/70 hover:text-white border border-white/10 transition-all"
                      title="Download Markdown"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDeleteNote(activeNote.id)}
                      className="p-2 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/30 transition-all"
                      title="Delete Note"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={handleSaveActiveNote}
                      disabled={saving}
                      className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition-all active:scale-95 shadow-md"
                    >
                      {saveSuccess ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Saved!</span>
                        </>
                      ) : saving ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <>
                          <Save className="w-3.5 h-3.5" />
                          <span>Save Note</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center text-white/40">
                <FileText className="w-12 h-12 mb-3 text-pink-400/40" />
                <p className="text-sm font-semibold">Koi note selected nahi hai</p>
                <button
                  onClick={handleCreateNote}
                  className="mt-3 px-4 py-1.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold"
                >
                  Naya Note Banayein
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
