import React, { useState, useEffect } from 'react';
import { 
  X, Mic, MicOff, Volume2, Sparkles, Database, Trash2, 
  Download, Shield, Camera, Eye, Sliders, Smartphone, Check, RefreshCw
} from 'lucide-react';
import { SettingsConfig } from '../../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: SettingsConfig;
  onUpdateConfig: (updated: Partial<SettingsConfig>) => void;
  memoriesCount: number;
  onClearMemories: () => void;
  onExportMemories: () => void;
  dbSyncStatus: 'synced' | 'local' | 'syncing';
  userEmail?: string | null;
  onTestVoice: () => void;
  onTestMic: () => void;
  micPermission: string;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  config,
  onUpdateConfig,
  memoriesCount,
  onClearMemories,
  onExportMemories,
  dbSyncStatus,
  userEmail,
  onTestVoice,
  onTestMic,
  micPermission,
}) => {
  const [activeTab, setActiveTab] = useState<'voice' | 'ai' | 'memory' | 'privacy'>('voice');
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [confirmClear, setConfirmClear] = useState(false);
  const [cameraTestActive, setCameraTestActive] = useState(false);
  const [cameraTestError, setCameraTestError] = useState<string | null>(null);

  useEffect(() => {
    if ('speechSynthesis' in window) {
      const loadVoices = () => {
        const voices = window.speechSynthesis.getVoices();
        setAvailableVoices(voices);
      };
      loadVoices();
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }, []);

  // Test camera preview in privacy tab
  const toggleCameraTest = async () => {
    if (cameraTestActive) {
      setCameraTestActive(false);
    } else {
      setCameraTestError(null);
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        stream.getTracks().forEach(t => t.stop());
        setCameraTestActive(true);
      } catch (err: any) {
        setCameraTestError(err.message || 'Camera permission denied or unavailable');
      }
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-[#0A0A0A] border border-[#262626] rounded-2xl flex flex-col max-h-[90vh] shadow-2xl text-white overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#1F1F1F]">
          <div className="flex items-center gap-2.5">
            <Sliders className="w-5 h-5 text-white" />
            <h2 className="text-base sm:text-lg font-bold tracking-tight">EZUMI Settings & Preferences</h2>
          </div>
          <button
            onClick={onClose}
            aria-label="Close settings"
            className="p-1.5 rounded-lg text-[#A0A0A0] hover:text-white hover:bg-[#1A1A1A] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center px-6 border-b border-[#1F1F1F] bg-[#0E0E0E] text-xs font-medium overflow-x-auto">
          <button
            onClick={() => setActiveTab('voice')}
            className={`py-3 px-4 border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'voice'
                ? 'border-white text-white font-semibold'
                : 'border-transparent text-[#A0A0A0] hover:text-white'
            }`}
          >
            <Mic className="w-4 h-4" />
            <span>Voice & Wake Word</span>
          </button>

          <button
            onClick={() => setActiveTab('ai')}
            className={`py-3 px-4 border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'ai'
                ? 'border-white text-white font-semibold'
                : 'border-transparent text-[#A0A0A0] hover:text-white'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>AI Model & Persona</span>
          </button>

          <button
            onClick={() => setActiveTab('memory')}
            className={`py-3 px-4 border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'memory'
                ? 'border-white text-white font-semibold'
                : 'border-transparent text-[#A0A0A0] hover:text-white'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Memory & Cloud SQL</span>
          </button>

          <button
            onClick={() => setActiveTab('privacy')}
            className={`py-3 px-4 border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'privacy'
                ? 'border-white text-white font-semibold'
                : 'border-transparent text-[#A0A0A0] hover:text-white'
            }`}
          >
            <Shield className="w-4 h-4" />
            <span>Privacy & Hardware</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-sm text-[#A0A0A0]">
          
          {/* TAB 1: VOICE & WAKE WORD */}
          {activeTab === 'voice' && (
            <div className="space-y-5">
              
              {/* Wake Word Detection */}
              <div className="bg-[#141414] border border-[#262626] rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-white font-semibold text-sm">Wake Word Detection ("Ezumi")</h3>
                    <p className="text-xs text-[#A0A0A0] mt-0.5">
                      Hands-free voice activation. Listens in background for "Ezumi" or "Hey Ezumi".
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.wakeWordEnabled}
                      onChange={(e) => onUpdateConfig({ wakeWordEnabled: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-[#262626] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-white" />
                  </label>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-[#1F1F1F]">
                  <span className="text-xs text-white">Chime sound on detection</span>
                  <input
                    type="checkbox"
                    checked={config.soundFeedback}
                    onChange={(e) => onUpdateConfig({ soundFeedback: e.target.checked })}
                    className="w-4 h-4 accent-white rounded"
                  />
                </div>
              </div>

              {/* Spoken Responses & TTS */}
              <div className="bg-[#141414] border border-[#262626] rounded-xl p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-white font-semibold text-sm">Auto-Speak Responses (TTS)</h3>
                    <p className="text-xs text-[#A0A0A0] mt-0.5">
                      Speak AI answers aloud using browser speech synthesis.
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.autoSpeakResponse}
                      onChange={(e) => onUpdateConfig({ autoSpeakResponse: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-[#262626] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-white" />
                  </label>
                </div>

                {/* Voice Selection */}
                <div>
                  <label className="block text-xs font-semibold text-white mb-1.5">Voice Model</label>
                  <select
                    value={config.selectedVoiceURI}
                    onChange={(e) => onUpdateConfig({ selectedVoiceURI: e.target.value })}
                    className="w-full bg-[#1A1A1A] border border-[#2B2B2B] rounded-lg px-3 py-2 text-white text-xs focus:outline-none focus:border-white"
                  >
                    <option value="">Default System Female / Natural Voice</option>
                    {availableVoices.map((v, i) => (
                      <option key={i} value={v.voiceURI}>
                        {v.name} ({v.lang})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Speech Rate & Pitch */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-white">Speech Rate</span>
                      <span className="text-[#A0A0A0]">{config.speechRate.toFixed(2)}x</span>
                    </div>
                    <input
                      type="range"
                      min="0.8"
                      max="1.4"
                      step="0.05"
                      value={config.speechRate}
                      onChange={(e) => onUpdateConfig({ speechRate: parseFloat(e.target.value) })}
                      className="w-full accent-white"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-white">Voice Pitch</span>
                      <span className="text-[#A0A0A0]">{config.speechPitch.toFixed(2)}</span>
                    </div>
                    <input
                      type="range"
                      min="0.8"
                      max="1.3"
                      step="0.05"
                      value={config.speechPitch}
                      onChange={(e) => onUpdateConfig({ speechPitch: parseFloat(e.target.value) })}
                      className="w-full accent-white"
                    />
                  </div>
                </div>

                {/* Test Voice Button */}
                <div className="pt-2 flex justify-end">
                  <button
                    onClick={onTestVoice}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#222222] hover:bg-[#2C2C2C] text-xs text-white border border-[#333333] transition-colors"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>Test Voice Playback</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: AI MODEL & PERSONA */}
          {activeTab === 'ai' && (
            <div className="space-y-5">
              <div className="bg-[#141414] border border-[#262626] rounded-xl p-4 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-white mb-1">Selected Intelligence Model</label>
                  <div className="w-full bg-[#1A1A1A] border border-[#2B2B2B] rounded-lg px-3 py-2 text-white text-xs flex items-center justify-between">
                    <span className="font-mono">models/gemini-3.8-flash</span>
                    <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-950 border border-emerald-700 text-emerald-300 font-semibold">
                      Active
                    </span>
                  </div>
                  <p className="text-[11px] text-[#A0A0A0] mt-1">
                    Google Gemini 3.8 Flash powers conversational reasoning, real-time responses, and tool planning.
                  </p>
                </div>

                {/* Persona Selector */}
                <div>
                  <label className="block text-xs font-semibold text-white mb-1.5">Companion Personality</label>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {[
                      { id: 'balanced', title: 'Balanced Companion', desc: 'Warm, intuitive, and natural' },
                      { id: 'concise', title: 'Alexa Assistant', desc: 'Brief, efficient, direct commands' },
                      { id: 'deep', title: 'Analytical & Tech', desc: 'In-depth, structured reasoning' },
                      { id: 'creative', title: 'Creative & Empathetic', desc: 'Expressive and thoughtful' },
                    ].map((p) => (
                      <button
                        key={p.id}
                        onClick={() => {
                          let instruction = '';
                          if (p.id === 'concise') {
                            instruction = 'You are EZUMI. Keep answers concise, clear, and direct like an Alexa voice assistant.';
                          } else if (p.id === 'deep') {
                            instruction = 'You are EZUMI, an expert AI engineer and analyst. Provide thorough technical analysis and code when requested.';
                          } else if (p.id === 'creative') {
                            instruction = 'You are EZUMI, an expressive, highly empathetic companion with natural conversational depth.';
                          } else {
                            instruction = 'You are EZUMI, an advanced personal AI companion combining ChatGPT intelligence with Alexa hands-free voice interaction.';
                          }
                          onUpdateConfig({ aiPersona: instruction });
                        }}
                        className={`p-2.5 rounded-lg border text-left transition-all ${
                          config.aiPersona.includes(p.id) || (p.id === 'balanced' && !config.aiPersona)
                            ? 'bg-white/10 border-white text-white'
                            : 'bg-[#1A1A1A] border-[#2B2B2B] text-[#A0A0A0] hover:text-white'
                        }`}
                      >
                        <div className="font-semibold text-white">{p.title}</div>
                        <div className="text-[10px] text-[#A0A0A0] mt-0.5">{p.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Custom System Instruction Box */}
                <div>
                  <label className="block text-xs font-semibold text-white mb-1.5">Custom Persona Instructions</label>
                  <textarea
                    value={config.aiPersona}
                    onChange={(e) => onUpdateConfig({ aiPersona: e.target.value })}
                    rows={4}
                    placeholder="Describe how EZUMI should behave..."
                    className="w-full bg-[#1A1A1A] border border-[#2B2B2B] rounded-lg p-3 text-white text-xs font-mono focus:outline-none focus:border-white leading-relaxed resize-none"
                  />
                </div>

                {/* Creativity / Temperature */}
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-white">Temperature (Creativity)</span>
                    <span className="text-[#A0A0A0]">{config.temperature.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="1.0"
                    step="0.05"
                    value={config.temperature}
                    onChange={(e) => onUpdateConfig({ temperature: parseFloat(e.target.value) })}
                    className="w-full accent-white"
                  />
                  <div className="flex justify-between text-[10px] text-[#707070] mt-1">
                    <span>Precise & Factual</span>
                    <span>Creative & Expressive</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: MEMORY & PERSISTENCE */}
          {activeTab === 'memory' && (
            <div className="space-y-5">
              <div className="bg-[#141414] border border-[#262626] rounded-xl p-4 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-[#1F1F1F]">
                  <div>
                    <h3 className="text-white font-semibold text-sm">Cloud SQL Database Persistence</h3>
                    <p className="text-xs text-[#A0A0A0] mt-0.5">
                      {userEmail ? `Connected as ${userEmail}` : 'Signed out (using browser local storage)'}
                    </p>
                  </div>
                  <span
                    className={`text-xs px-2.5 py-1 rounded-full font-semibold border ${
                      dbSyncStatus === 'synced'
                        ? 'bg-emerald-950/60 border-emerald-700 text-emerald-300'
                        : dbSyncStatus === 'syncing'
                        ? 'bg-blue-950/60 border-blue-700 text-blue-300'
                        : 'bg-zinc-800 border-zinc-700 text-zinc-300'
                    }`}
                  >
                    {dbSyncStatus === 'synced' ? 'Cloud SQL Active' : dbSyncStatus === 'syncing' ? 'Syncing...' : 'Local Storage'}
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs py-1">
                  <span className="text-white">Total Stored Memories / Turns</span>
                  <span className="font-mono text-white bg-[#1F1F1F] px-2.5 py-0.5 rounded-md">
                    {memoriesCount} records
                  </span>
                </div>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-3 border-t border-[#1F1F1F]">
                  <button
                    onClick={onExportMemories}
                    className="flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#1F1F1F] hover:bg-[#2A2A2A] text-xs text-white border border-[#333333] transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export Conversation</span>
                  </button>

                  {confirmClear ? (
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-red-400">Are you sure?</span>
                      <button
                        onClick={() => {
                          onClearMemories();
                          setConfirmClear(false);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-xs text-white font-semibold transition-colors"
                      >
                        Yes, Delete
                      </button>
                      <button
                        onClick={() => setConfirmClear(false)}
                        className="px-2 py-1.5 text-xs text-[#A0A0A0] hover:text-white"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setConfirmClear(true)}
                      className="flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-lg bg-red-950/40 hover:bg-red-950/70 text-xs text-red-300 border border-red-800/50 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Clear All Memory</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: PRIVACY & HARDWARE */}
          {activeTab === 'privacy' && (
            <div className="space-y-5">
              
              {/* Android Tablet Desk Mode: Keep Screen Awake */}
              <div className="bg-[#141414] border border-[#262626] rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-start gap-2.5">
                    <Smartphone className="w-5 h-5 text-white shrink-0 mt-0.5" />
                    <div>
                      <h3 className="text-white font-semibold text-sm">Tablet Desk Mode (Keep Screen On)</h3>
                      <p className="text-xs text-[#A0A0A0] mt-0.5">
                        Prevents the tablet screen from sleeping when placed on a table like an Echo Show or Google Nest Hub.
                      </p>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input
                      type="checkbox"
                      checked={config.screenAwake}
                      onChange={(e) => onUpdateConfig({ screenAwake: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-[#262626] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-white" />
                  </label>
                </div>
              </div>

              {/* Hardware Permission Verification */}
              <div className="bg-[#141414] border border-[#262626] rounded-xl p-4 space-y-4">
                <h3 className="text-white font-semibold text-sm">Hardware Permissions & Verification</h3>
                
                {/* Microphone */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-[#1A1A1A] border border-[#262626]">
                  <div className="flex items-center gap-2.5">
                    <Mic className="w-4 h-4 text-white" />
                    <div>
                      <div className="text-xs font-semibold text-white">Microphone Audio</div>
                      <div className="text-[11px] text-[#A0A0A0]">Permission status: {micPermission}</div>
                    </div>
                  </div>
                  <button
                    onClick={onTestMic}
                    className="px-3 py-1.5 rounded-lg bg-[#252525] hover:bg-[#303030] text-xs text-white border border-[#3A3A3A] transition-colors"
                  >
                    Test Mic
                  </button>
                </div>

                {/* Camera / Vision */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-[#1A1A1A] border border-[#262626]">
                  <div className="flex items-center gap-2.5">
                    <Camera className="w-4 h-4 text-white" />
                    <div>
                      <div className="text-xs font-semibold text-white">Camera & Real-time Vision</div>
                      <div className="text-[11px] text-[#A0A0A0]">Used during Face-to-Face Video Calling</div>
                    </div>
                  </div>
                  <button
                    onClick={toggleCameraTest}
                    className="px-3 py-1.5 rounded-lg bg-[#252525] hover:bg-[#303030] text-xs text-white border border-[#3A3A3A] transition-colors"
                  >
                    {cameraTestActive ? 'Stop Test' : 'Test Camera'}
                  </button>
                </div>

                {cameraTestActive && (
                  <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-700/60 text-xs text-emerald-300 flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Camera is functional and ready for Face-to-Face video calls!</span>
                  </div>
                )}

                {cameraTestError && (
                  <div className="p-3 rounded-lg bg-red-950/40 border border-red-700/60 text-xs text-red-300">
                    {cameraTestError}
                  </div>
                )}
              </div>

              {/* Privacy Notice */}
              <div className="p-4 rounded-xl bg-[#111111] border border-[#222222] text-xs text-[#808080] leading-relaxed">
                <span className="text-white font-medium">Privacy Protection: </span>
                Voice audio is processed locally using your device's native SpeechRecognition. No audio recordings are permanently stored on remote servers without your command. All AI calls run through secure server-side authenticated proxies.
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="flex items-center justify-end px-6 py-4 border-t border-[#1F1F1F] bg-[#0A0A0A]">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-white hover:bg-neutral-200 text-black text-xs font-bold transition-all active:scale-95 shadow-md"
          >
            Save & Done
          </button>
        </div>

      </div>
    </div>
  );
};
