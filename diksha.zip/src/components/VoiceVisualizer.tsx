import React from 'react';
import { Mic, MicOff, Volume2, Sparkles, AlertCircle } from 'lucide-react';
import { AssistantVisualState } from '../../types';

interface VoiceVisualizerProps {
  state: AssistantVisualState;
  wakeWordEnabled: boolean;
  micPermission: 'granted' | 'denied' | 'prompt' | 'unknown';
  isListening: boolean;
  isSpeaking: boolean;
  lastTranscript?: string;
  onToggleListening: () => void;
  onStopSpeaking: () => void;
  wakeWordTriggered: boolean;
}

export const VoiceVisualizer: React.FC<VoiceVisualizerProps> = ({
  state,
  wakeWordEnabled,
  micPermission,
  isListening,
  isSpeaking,
  lastTranscript,
  onToggleListening,
  onStopSpeaking,
  wakeWordTriggered,
}) => {
  return (
    <div className="w-full flex flex-col items-center justify-center p-3 select-none">
      {/* Central Visualizer Orb */}
      <div className="relative flex items-center justify-center mb-3">
        {/* Glow backdrop based on state */}
        <div
          className={`absolute rounded-full transition-all duration-700 pointer-events-none ${
            wakeWordTriggered
              ? 'w-36 h-36 bg-emerald-500/30 blur-2xl scale-125'
              : state === 'listening'
              ? 'w-32 h-32 bg-cyan-500/25 blur-2xl animate-pulse'
              : state === 'speaking'
              ? 'w-32 h-32 bg-pink-500/30 blur-2xl animate-pulse'
              : state === 'processing'
              ? 'w-28 h-28 bg-purple-500/25 blur-xl'
              : 'w-24 h-24 bg-white/5 blur-lg'
          }`}
        />

        {/* Outer Orbit Rings for Processing */}
        {state === 'processing' && (
          <div className="absolute w-24 h-24 rounded-full border-2 border-dashed border-purple-400/60 animate-spin" />
        )}

        {/* Listening Ripple Rings */}
        {(state === 'listening' || wakeWordTriggered) && (
          <>
            <div className="absolute w-28 h-28 rounded-full border border-cyan-400/30 animate-ping" />
            <div className="absolute w-20 h-20 rounded-full border border-cyan-300/40 animate-pulse" />
          </>
        )}

        {/* Main Action Circle Button */}
        <button
          onClick={onToggleListening}
          aria-label={isListening ? 'Mute listening' : 'Start listening'}
          className={`relative z-10 w-20 h-20 rounded-full flex flex-col items-center justify-center transition-all duration-300 shadow-2xl ${
            wakeWordTriggered
              ? 'bg-gradient-to-tr from-emerald-600 to-teal-400 border-2 border-emerald-300 scale-105 shadow-emerald-500/40'
              : state === 'listening'
              ? 'bg-gradient-to-tr from-cyan-600 to-blue-500 border-2 border-cyan-300 scale-105 shadow-cyan-500/40'
              : state === 'speaking'
              ? 'bg-gradient-to-tr from-pink-600 to-purple-600 border-2 border-pink-300 shadow-pink-500/40'
              : state === 'processing'
              ? 'bg-gradient-to-tr from-purple-700 to-indigo-600 border-2 border-purple-400'
              : 'bg-[#141414] hover:bg-[#1C1C1C] border border-[#2B2B2B] hover:border-[#404040]'
          }`}
        >
          {state === 'speaking' ? (
            /* Equalizer Voice Wave Bars */
            <div className="flex items-center gap-1 h-6">
              <span className="w-1 bg-white rounded-full h-3 animate-bounce [animation-delay:0ms]" />
              <span className="w-1 bg-white rounded-full h-6 animate-bounce [animation-delay:150ms]" />
              <span className="w-1 bg-white rounded-full h-4 animate-bounce [animation-delay:300ms]" />
              <span className="w-1 bg-white rounded-full h-5 animate-bounce [animation-delay:100ms]" />
            </div>
          ) : state === 'listening' || wakeWordTriggered ? (
            <Mic className="w-7 h-7 text-white animate-pulse" />
          ) : state === 'processing' ? (
            <Sparkles className="w-7 h-7 text-white animate-spin" />
          ) : (
            <Mic className="w-6 h-6 text-[#A0A0A0] hover:text-white transition-colors" />
          )}

          {/* Subtext under icon */}
          <span className="text-[9px] font-semibold uppercase tracking-wider text-white/80 mt-1">
            {wakeWordTriggered
              ? 'Heard!'
              : state === 'listening'
              ? 'Listening'
              : state === 'speaking'
              ? 'Speaking'
              : state === 'processing'
              ? 'Thinking'
              : 'Standby'}
          </span>
        </button>
      </div>

      {/* Real-time Status & Live Transcript */}
      <div className="flex flex-col items-center gap-1 max-w-md text-center">
        {wakeWordTriggered ? (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-medium animate-pulse">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Wake word "Ezumi" detected! Speak your command...</span>
          </div>
        ) : lastTranscript && (state === 'listening' || state === 'processing') ? (
          <div className="px-3 py-1 rounded-xl bg-[#141414] border border-[#262626] text-xs text-white/90 italic max-w-sm line-clamp-2">
            "{lastTranscript}"
          </div>
        ) : (
          <div className="text-xs text-[#A0A0A0] flex items-center gap-1.5">
            {wakeWordEnabled ? (
              <span>Say <strong className="text-white">"Ezumi"</strong> or tap the orb to speak</span>
            ) : (
              <span>Tap the orb or mic below to speak</span>
            )}
          </div>
        )}

        {/* Microphone Permission Badge & Action bar */}
        <div className="flex items-center gap-2 mt-1">
          <div
            className={`flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full border ${
              micPermission === 'granted'
                ? 'bg-emerald-950/40 border-emerald-800 text-emerald-400'
                : micPermission === 'denied'
                ? 'bg-red-950/40 border-red-800 text-red-400'
                : 'bg-amber-950/40 border-amber-800 text-amber-400'
            }`}
            title={`Microphone: ${micPermission}`}
          >
            {micPermission === 'granted' ? (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            ) : micPermission === 'denied' ? (
              <MicOff className="w-2.5 h-2.5" />
            ) : (
              <AlertCircle className="w-2.5 h-2.5" />
            )}
            <span className="capitalize">Mic: {micPermission}</span>
          </div>

          {/* Stop Speaking Button if assistant is talking */}
          {isSpeaking && (
            <button
              onClick={onStopSpeaking}
              className="flex items-center gap-1 text-[10px] px-2.5 py-0.5 rounded-full bg-red-950/60 border border-red-600/50 text-red-300 hover:bg-red-900/60 transition-colors"
            >
              <Volume2 className="w-2.5 h-2.5" />
              <span>Stop Speaking</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
