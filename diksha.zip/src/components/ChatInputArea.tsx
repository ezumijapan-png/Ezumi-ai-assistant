import React, { useRef, useEffect } from 'react';
import { ArrowUp, Mic, MicOff, Square, Sparkles } from 'lucide-react';

interface ChatInputAreaProps {
  input: string;
  setInput: (value: string) => void;
  onSend: () => void;
  isProcessing: boolean;
  isListening: boolean;
  onToggleMic: () => void;
  isSpeaking: boolean;
  onStopSpeaking: () => void;
  wakeWordEnabled: boolean;
}

export const ChatInputArea: React.FC<ChatInputAreaProps> = ({
  input,
  setInput,
  onSend,
  isProcessing,
  isListening,
  onToggleMic,
  isSpeaking,
  onStopSpeaking,
  wakeWordEnabled,
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [input]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSend();
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto px-4 pb-4 pt-1">
      {/* Outer Input Container */}
      <div className="relative bg-[#101010] border border-[#262626] focus-within:border-[#404040] rounded-2xl p-2 transition-all shadow-xl">
        
        {/* Text Input Area */}
        <textarea
          ref={textareaRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={
            isListening 
              ? 'Listening to your voice...' 
              : wakeWordEnabled 
              ? 'Message EZUMI, or say "Ezumi"...' 
              : 'Message EZUMI...'
          }
          rows={1}
          disabled={isProcessing}
          className="w-full bg-transparent text-white placeholder-[#606060] text-sm px-3 pt-1.5 pb-2 focus:outline-none resize-none leading-relaxed"
        />

        {/* Bottom Control Bar */}
        <div className="flex items-center justify-between pt-1 px-1">
          {/* Left: Wake Word / Mode Hint */}
          <div className="flex items-center gap-1.5 text-[11px] text-[#707070]">
            {isSpeaking ? (
              <button
                onClick={onStopSpeaking}
                className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-red-950/60 border border-red-700/60 text-red-300 hover:bg-red-900/60 transition-colors"
              >
                <Square className="w-2.5 h-2.5 fill-current" />
                <span>Stop Speaking</span>
              </button>
            ) : wakeWordEnabled ? (
              <span className="flex items-center gap-1 text-emerald-400/90 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                "Ezumi" wake word active
              </span>
            ) : (
              <span>Shift+Enter for newline</span>
            )}
          </div>

          {/* Right: Dictation Mic & Send Button */}
          <div className="flex items-center gap-2">
            {/* Microphone Dictation Button */}
            <button
              onClick={onToggleMic}
              aria-label={isListening ? 'Stop listening' : 'Start dictation'}
              className={`p-2 rounded-xl transition-all ${
                isListening
                  ? 'bg-red-600 text-white animate-pulse shadow-md'
                  : 'bg-[#1C1C1C] hover:bg-[#282828] text-[#A0A0A0] hover:text-white border border-[#2E2E2E]'
              }`}
              title={isListening ? 'Listening... click to stop' : 'Voice dictation'}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            {/* Send Button */}
            <button
              onClick={onSend}
              disabled={!input.trim() || isProcessing}
              aria-label="Send message"
              className={`p-2 rounded-xl transition-all ${
                input.trim() && !isProcessing
                  ? 'bg-white text-black hover:bg-neutral-200 active:scale-95 shadow-md'
                  : 'bg-[#1C1C1C] text-[#555555] cursor-not-allowed border border-[#242424]'
              }`}
            >
              <ArrowUp className="w-4 h-4 stroke-[2.5]" />
            </button>
          </div>
        </div>
      </div>

      {/* Subtle Bottom Disclaimer */}
      <div className="text-center mt-2 text-[10px] text-[#505050]">
        EZUMI can make mistakes. Verify important facts and information.
      </div>
    </div>
  );
};
