import React, { useState, useEffect, useRef, useCallback } from 'react';
import { TranscriptionTurn, AppStatus, AssistantVisualState, SettingsConfig, VoiceSessionState } from './types';
import { VoiceService } from './services/gemini';
import { voiceController } from './src/services/voiceController';
import { useAuth } from './src/context/AuthContext';
import { 
  Heart, Loader2, Menu, X, Sliders, Plus,
  Database, Video, VideoOff, Mic, MicOff, Phone, 
  Sparkles, FileText, Terminal, Globe, Smartphone, Volume2,
  ChevronRight, AlertCircle, ArrowUp
} from 'lucide-react';
import { VideoCallStage } from './src/components/VideoCallStage';
import { SmartNotepadModal } from './src/components/SmartNotepadModal';
import { AutonomousTaskModal } from './src/components/AutonomousTaskModal';
import { WebResearchNewsModal } from './src/components/WebResearchNewsModal';
import { DeviceCommModal } from './src/components/DeviceCommModal';
import { VoiceVisualizer } from './src/components/VoiceVisualizer';
import { SettingsModal } from './src/components/SettingsModal';
import { ChatSidebar } from './src/components/ChatSidebar';
import { ChatMessageView } from './src/components/ChatMessageView';
import { ChatInputArea } from './src/components/ChatInputArea';
import { playWakeChime, playSuccessChime } from './src/utils/wakeChime';

const STORAGE_KEY = 'ezumi_memories_v2';
const SETTINGS_KEY = 'ezumi_settings_v2';

const DEFAULT_SETTINGS: SettingsConfig = {
  wakeWordEnabled: true,
  continuousListening: true,
  autoSpeakResponse: true,
  speechRate: 1.05,
  speechPitch: 1.05,
  selectedVoiceURI: '',
  modelName: 'models/gemini-3.8-flash',
  aiPersona: 'You are EZUMI, an advanced personal AI companion combining ChatGPT intelligence with Alexa hands-free voice interaction. You are warm, intelligent, attentive, clear, and speak naturally in English or Hinglish.',
  temperature: 0.7,
  screenAwake: true,
  soundFeedback: true,
};

const App: React.FC = () => {
  const { user, token, loading: authLoading, signInWithGoogle, logout, getToken } = useAuth();
  
  // Navigation & Layout
  const [activeView, setActiveView] = useState<'chat' | 'video_call'>('chat');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Settings Configuration
  const [config, setConfig] = useState<SettingsConfig>(() => {
    try {
      const saved = localStorage.getItem(SETTINGS_KEY);
      return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  // Assistant State & Visualizer
  const [assistantState, setAssistantState] = useState<AssistantVisualState>('standby');
  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [loadingMsg, setLoadingMsg] = useState<string>("Connecting to EZUMI...");
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [inputText, setInputText] = useState<string>('');
  const [lastTranscript, setLastTranscript] = useState<string>('');
  const [micPermission, setMicPermission] = useState<'granted' | 'denied' | 'prompt' | 'unknown'>('unknown');

  // Wake Word Engine
  const [wakeWordTriggered, setWakeWordTriggered] = useState(false);
  const [isDictating, setIsDictating] = useState(false);

  // Persistence & Database Sync
  const [turns, setTurns] = useState<TranscriptionTurn[]>([]);
  const [dbSyncStatus, setDbSyncStatus] = useState<'synced' | 'local' | 'syncing'>('local');

  // Subsystem Modals
  const [isNotesOpen, setIsNotesOpen] = useState(false);
  const [isTasksOpen, setIsTasksOpen] = useState(false);
  const [isResearchOpen, setIsResearchOpen] = useState(false);
  const [isDeviceOpen, setIsDeviceOpen] = useState(false);
  const [initialResearchQuery, setInitialResearchQuery] = useState('');
  const [researchMode, setResearchMode] = useState<'search' | 'news'>('search');

  // Video Call Mode & Camera State
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [cameraFacingMode, setCameraFacingMode] = useState<'user' | 'environment'>('user');
  const [cameraLoading, setCameraLoading] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [micMuted, setMicMuted] = useState<boolean>(false);
  const [callDuration, setCallDuration] = useState<number>(0);
  const [isScreenSharing, setIsScreenSharing] = useState<boolean>(false);

  // Companion Vitals
  const [hydration, setHydration] = useState(85);
  const [hunger, setHunger] = useState(20);
  const [mood, setMood] = useState(100);

  const videoRef = useRef<HTMLVideoElement>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const voiceServiceRef = useRef<VoiceService>(new VoiceService());
  const chatScrollRef = useRef<HTMLDivElement>(null);
  const wakeLockRef = useRef<any>(null);

  // Auto-scroll chat to bottom
  const scrollToBottom = useCallback(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [turns, isProcessing, scrollToBottom]);

  // Persist Settings
  const handleUpdateConfig = (updated: Partial<SettingsConfig>) => {
    setConfig((prev) => {
      const next = { ...prev, ...updated };
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(next));
      return next;
    });
  };

  // Check Microphone Permission on mount
  useEffect(() => {
    if (navigator.permissions && navigator.permissions.query) {
      navigator.permissions
        .query({ name: 'microphone' as PermissionName })
        .then((permissionStatus) => {
          setMicPermission(permissionStatus.state as any);
          permissionStatus.onchange = () => {
            setMicPermission(permissionStatus.state as any);
          };
        })
        .catch(() => {
          setMicPermission('unknown');
        });
    }
  }, []);

  // Android Tablet Desk Mode: Keep Screen Awake via WakeLock API
  useEffect(() => {
    const acquireWakeLock = async () => {
      if (config.screenAwake && 'wakeLock' in navigator) {
        try {
          if (!wakeLockRef.current) {
            wakeLockRef.current = await (navigator as any).wakeLock.request('screen');
            wakeLockRef.current.addEventListener('release', () => {
              wakeLockRef.current = null;
            });
          }
        } catch (err) {
          console.warn('Screen WakeLock request failed:', err);
        }
      } else if (!config.screenAwake && wakeLockRef.current) {
        try {
          await wakeLockRef.current.release();
          wakeLockRef.current = null;
        } catch (err) {
          console.warn('Screen WakeLock release failed:', err);
        }
      }
    };

    acquireWakeLock();
    return () => {
      if (wakeLockRef.current) {
        wakeLockRef.current.release().catch(() => {});
      }
    };
  }, [config.screenAwake]);

  // Speech Synthesis Helper
  const speakText = useCallback(
    (text: string) => {
      if (!('speechSynthesis' in window)) return;
      window.speechSynthesis.cancel();

      // Clean markdown tags or bullets for cleaner speech
      const cleanText = text
        .replace(/[*#_`~>]/g, '')
        .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
        .replace(/```[\s\S]*?```/g, 'Code block omitted.')
        .trim();

      if (!cleanText) return;

      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.rate = config.speechRate || 1.05;
      utterance.pitch = config.speechPitch || 1.05;

      const voices = window.speechSynthesis.getVoices();
      if (config.selectedVoiceURI) {
        const found = voices.find((v) => v.voiceURI === config.selectedVoiceURI);
        if (found) utterance.voice = found;
      } else {
        // Natural preference for Hindi/Indian English female voice if available
        const preferredVoice = voices.find(
          (v) =>
            v.lang.includes('hi') ||
            v.lang.includes('IN') ||
            v.name.toLowerCase().includes('female') ||
            v.name.toLowerCase().includes('google')
        );
        if (preferredVoice) utterance.voice = preferredVoice;
      }

      utterance.onstart = () => {
        setIsSpeaking(true);
        setAssistantState('speaking');
        voiceController.pauseForAssistantSpeaking();
      };

      utterance.onend = () => {
        setIsSpeaking(false);
        setAssistantState('standby');
        voiceController.resumeAfterAssistantSpeaking();
      };

      utterance.onerror = () => {
        setIsSpeaking(false);
        setAssistantState('standby');
        voiceController.resumeAfterAssistantSpeaking();
      };

      window.speechSynthesis.speak(utterance);
    },
    [config.speechRate, config.speechPitch, config.selectedVoiceURI]
  );

  const stopSpeaking = useCallback(() => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
    if (assistantState === 'speaking') {
      setAssistantState('standby');
    }
    voiceController.resumeAfterAssistantSpeaking();
  }, [assistantState]);

  // Load Memories from Cloud SQL or LocalStorage
  useEffect(() => {
    const loadMemoriesAndVitals = async () => {
      if (user) {
        setDbSyncStatus('syncing');
        try {
          const currentToken = await getToken();
          if (currentToken) {
            const [memRes, vitRes] = await Promise.all([
              fetch('/api/memories', {
                headers: { Authorization: `Bearer ${currentToken}` },
              }),
              fetch('/api/vitals', {
                headers: { Authorization: `Bearer ${currentToken}` },
              }),
            ]);

            if (memRes.ok) {
              const memData = await memRes.json();
              if (memData.memories && memData.memories.length > 0) {
                const cloudTurns: TranscriptionTurn[] = memData.memories.map((m: any) => ({
                  role: m.role,
                  text: m.text,
                  timestamp: new Date(m.timestamp),
                }));
                setTurns(cloudTurns);
                localStorage.setItem(STORAGE_KEY, JSON.stringify(cloudTurns));
              }
            }

            if (vitRes.ok) {
              const vitData = await vitRes.json();
              if (vitData.vitals) {
                setHydration(vitData.vitals.hydration ?? 85);
                setHunger(vitData.vitals.hunger ?? 20);
                setMood(vitData.vitals.mood ?? 100);
              }
            }

            setDbSyncStatus('synced');
            return;
          }
        } catch (err) {
          console.error('Failed to sync with Cloud SQL:', err);
          setDbSyncStatus('local');
        }
      }

      // Local storage fallback
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          const revived = parsed.map((t: any) => ({
            ...t,
            timestamp: new Date(t.timestamp),
          }));
          setTurns(revived);
        } catch (e) {
          console.error(e);
        }
      }
      setDbSyncStatus(user ? 'synced' : 'local');
    };

    if (!authLoading) {
      loadMemoriesAndVitals();
    }
  }, [user, authLoading, getToken]);

  // Persist Turn to Cloud SQL & LocalStorage
  const persistTurn = useCallback(
    async (turn: { role: 'user' | 'assistant'; text: string }) => {
      const newTurn: TranscriptionTurn = { ...turn, timestamp: new Date() };
      setTurns((prev) => {
        const next = [...prev, newTurn];
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
        return next;
      });

      if (user) {
        try {
          const currentToken = await getToken();
          if (currentToken) {
            await fetch('/api/memories', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${currentToken}`,
              },
              body: JSON.stringify(turn),
            });
          }
        } catch (err) {
          console.error('Failed to persist turn to Cloud SQL:', err);
        }
      }
    },
    [user, getToken]
  );

  // Clear Memories
  const clearAllMemories = async () => {
    setTurns([]);
    localStorage.removeItem(STORAGE_KEY);
    if (user) {
      try {
        const currentToken = await getToken();
        if (currentToken) {
          await fetch('/api/memories', {
            method: 'DELETE',
            headers: { Authorization: `Bearer ${currentToken}` },
          });
        }
      } catch (err) {
        console.error('Failed to delete memories from Cloud SQL:', err);
      }
    }
  };

  // Export Memories
  const exportMemories = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(turns, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `ezumi_conversation_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Central Command & Chat Handler
  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputText).trim();
    if (!query || isProcessing) return;

    setInputText('');
    stopSpeaking();
    setIsProcessing(true);
    setAssistantState('processing');
    voiceController.setProcessing();
    setErrorMsg(null);

    // Append user turn
    await persistTurn({ role: 'user', text: query });

    try {
      // 1. Natural Language Intent Check for subsystem triggers
      const intentRes = await fetch('/api/ai/intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: query }),
      });

      if (intentRes.ok) {
        const intentData = await intentRes.json();
        
        if (intentData.intent === 'SEARCH') {
          setInitialResearchQuery(intentData.parameters?.query || query.replace(/ezumi/gi, ''));
          setResearchMode('search');
          setIsResearchOpen(true);
          const reply = intentData.spokenResponsePrompt || `I've opened Web Research to search for "${intentData.parameters?.query || query}".`;
          await persistTurn({ role: 'assistant', text: reply });
          if (config.autoSpeakResponse) speakText(reply);
          setIsProcessing(false);
          setAssistantState('standby');
          return;
        }

        if (intentData.intent === 'READ_NEWS') {
          setResearchMode('news');
          setIsResearchOpen(true);
          const reply = intentData.spokenResponsePrompt || "Opening latest global news intelligence.";
          await persistTurn({ role: 'assistant', text: reply });
          if (config.autoSpeakResponse) speakText(reply);
          setIsProcessing(false);
          setAssistantState('standby');
          return;
        }

        if (intentData.intent === 'NOTE_TAKING') {
          setIsNotesOpen(true);
          const reply = intentData.spokenResponsePrompt || "Smart Notepad ready. Go ahead and dictate your note.";
          await persistTurn({ role: 'assistant', text: reply });
          if (config.autoSpeakResponse) speakText(reply);
          setIsProcessing(false);
          setAssistantState('standby');
          return;
        }

        if (intentData.intent === 'TASK_CREATE' || intentData.intent === 'TASK_CONTROL') {
          setIsTasksOpen(true);
          const reply = intentData.spokenResponsePrompt || "Opening Autonomous Tasks engine.";
          await persistTurn({ role: 'assistant', text: reply });
          if (config.autoSpeakResponse) speakText(reply);
          setIsProcessing(false);
          setAssistantState('standby');
          return;
        }

        if (intentData.intent === 'CALL_PHONE' || intentData.intent === 'MESSAGE_WHATSAPP') {
          setIsDeviceOpen(true);
          const reply = intentData.spokenResponsePrompt || "Device Communication hub is open.";
          await persistTurn({ role: 'assistant', text: reply });
          if (config.autoSpeakResponse) speakText(reply);
          setIsProcessing(false);
          setAssistantState('standby');
          return;
        }
      }

      // 2. Main Conversational AI Chat via Gemini Flash
      const chatRes = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: turns.slice(-10),
          persona: config.aiPersona,
          temperature: config.temperature,
        }),
      });

      if (!chatRes.ok) {
        throw new Error('Chat service encountered an error');
      }

      const chatData = await chatRes.json();
      const reply = chatData.reply || "I'm right here with you.";

      await persistTurn({ role: 'assistant', text: reply });

      if (config.soundFeedback) {
        playSuccessChime();
      }

      if (config.autoSpeakResponse) {
        speakText(reply);
      } else {
        setAssistantState('standby');
        voiceController.setStandby();
      }
    } catch (err: any) {
      console.error('Chat error:', err);
      setErrorMsg(err.message || 'Failed to receive response from EZUMI');
      setAssistantState('standby');
      voiceController.setStandby();
    } finally {
      setIsProcessing(false);
    }
  };

  // Stable refs to prevent callback teardown loops across React re-renders
  const handleSendMessageRef = useRef<(text?: string) => Promise<void>>();
  const persistTurnRef = useRef<(turn: { role: 'user' | 'assistant'; text: string }) => Promise<void>>();
  const speakTextRef = useRef<(text: string) => void>();
  const configRef = useRef(config);

  useEffect(() => {
    handleSendMessageRef.current = handleSendMessage;
    persistTurnRef.current = persistTurn;
    speakTextRef.current = speakText;
    configRef.current = config;
  });

  // ============================================================
  // UNIFIED VOICE ENGINE & STATE CONTROLLER
  // Prevents on/off loops, conflicting sessions, and unhandled errors
  // ============================================================
  useEffect(() => {
    voiceController.setCallbacks({
      onStateChange: (newState, error) => {
        if (error) {
          setErrorMsg(error);
        } else if (newState !== 'ERROR') {
          setErrorMsg((prev) => (prev && prev.includes('Microphone') ? null : prev));
        }

        if (newState === 'LISTENING') {
          setAssistantState('listening');
          setIsDictating(voiceController.getMode() === 'DICTATION');
        } else if (newState === 'SPEAKING') {
          setAssistantState('speaking');
          setIsSpeaking(true);
        } else if (newState === 'PROCESSING') {
          setAssistantState('processing');
        } else {
          setAssistantState('standby');
          setIsDictating(false);
          setIsSpeaking(false);
        }
      },
      onTranscript: (transcript, isFinal, mode) => {
        setLastTranscript(transcript);
        if (mode === 'DICTATION') {
          setInputText(transcript);
        }
      },
      onWakeWordDetected: (commandAfterWake, isFinal) => {
        if (configRef.current.soundFeedback) {
          playWakeChime();
        }

        setWakeWordTriggered(true);
        setTimeout(() => setWakeWordTriggered(false), 2500);

        if (isFinal) {
          if (commandAfterWake.length > 2) {
            handleSendMessageRef.current?.(commandAfterWake);
          } else {
            const greeting = "Yes, I am listening. What can I do for you?";
            persistTurnRef.current?.({ role: 'assistant', text: greeting });
            if (configRef.current.autoSpeakResponse) {
              speakTextRef.current?.(greeting);
            }
          }
        }
      },
      onPermissionStatus: (perm) => {
        setMicPermission(perm);
      },
    });

    return () => {
      voiceController.stop();
    };
  }, []);

  // Control Wake-Word Background Listener
  useEffect(() => {
    // If user is on the Live Video Call stage, release browser SpeechRecognition completely
    if (activeView === 'video_call') {
      voiceController.stop();
      return;
    }

    if (config.wakeWordEnabled) {
      voiceController.startWakeWord();
    } else {
      voiceController.stop();
    }

    return () => {
      voiceController.stop();
    };
  }, [config.wakeWordEnabled, activeView]);

  // Manual Microphone Dictation Toggle (Push-to-Talk / Click-to-Speak)
  const toggleManualDictation = async () => {
    if (!voiceController.isSupported()) {
      setErrorMsg('Speech recognition is not supported in this browser.');
      return;
    }

    if (micPermission === 'denied') {
      setErrorMsg('Microphone access is blocked. Please enable microphone permissions in your browser.');
      return;
    }

    if (micPermission === 'prompt' || micPermission === 'unknown') {
      const ok = await voiceController.requestMicrophonePermission();
      if (!ok) return;
    }

    const currentMode = voiceController.getMode();
    const currentState = voiceController.getState();

    // If currently dictating or listening, cleanly toggle off
    if (currentMode === 'DICTATION' && (currentState === 'LISTENING' || isDictating)) {
      setIsDictating(false);
      if (config.wakeWordEnabled && activeView === 'chat') {
        voiceController.startWakeWord();
      } else {
        voiceController.stop();
      }
      return;
    }

    // Stop assistant speech if speaking before starting user dictation
    stopSpeaking();
    setIsDictating(true);
    voiceController.startDictation();
  };

  // Video Call Mode Helpers
  const startCameraStream = async (facing: 'user' | 'environment' = 'user') => {
    setCameraLoading(true);
    setCameraError(null);
    try {
      if (cameraStreamRef.current) {
        cameraStreamRef.current.getTracks().forEach((t) => t.stop());
      }
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraError('Camera access not supported on this browser.');
        setCameraActive(false);
        return null;
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: facing,
          width: { ideal: 640 },
          height: { ideal: 480 },
        },
        audio: false,
      });
      cameraStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        try {
          await videoRef.current.play();
        } catch (playErr) {
          console.log('Video play notice:', playErr);
        }
      }
      setCameraActive(true);
      setCameraFacingMode(facing);
      setIsScreenSharing(false);
      return stream;
    } catch (err: any) {
      setCameraError('Camera permission was denied. You can continue in voice/avatar mode.');
      setCameraActive(false);
      return null;
    } finally {
      setCameraLoading(false);
    }
  };

  const stopCameraStream = () => {
    if (cameraStreamRef.current) {
      cameraStreamRef.current.getTracks().forEach((t) => t.stop());
      cameraStreamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
    setIsScreenSharing(false);
  };

  const toggleCamera = async () => {
    if (cameraActive) {
      stopCameraStream();
    } else {
      await startCameraStream(cameraFacingMode);
    }
  };

  const toggleFacingMode = async () => {
    const nextMode = cameraFacingMode === 'user' ? 'environment' : 'user';
    await startCameraStream(nextMode);
  };

  const toggleMic = () => {
    const nextState = !micMuted;
    setMicMuted(nextState);
    voiceServiceRef.current.setMicMuted(nextState);
  };

  const toggleScreenShare = async () => {
    if (isScreenSharing) {
      setIsScreenSharing(false);
      await startCameraStream(cameraFacingMode);
    } else {
      try {
        if (cameraStreamRef.current) {
          cameraStreamRef.current.getTracks().forEach((t) => t.stop());
        }
        const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
        cameraStreamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
        setIsScreenSharing(true);
        setCameraActive(true);
        stream.getVideoTracks()[0].onended = () => {
          setIsScreenSharing(false);
          startCameraStream(cameraFacingMode);
        };
      } catch (err) {
        console.error('Screen sharing canceled:', err);
      }
    }
  };

  const launchVideoCallStage = async () => {
    voiceController.stop();
    setActiveView('video_call');
    setStatus(AppStatus.CONNECTING);
    setLoadingMsg('Starting Face-to-Face Video Call with EZUMI...');
    const stream = await startCameraStream(cameraFacingMode);

    try {
      await voiceServiceRef.current.connect(
        {
          onTranscription: (text, role) => {
            persistTurn({ role, text });
          },
          onError: (err) => {
            setErrorMsg(err);
            setStatus(AppStatus.ERROR);
          },
          onClose: () => {
            setStatus(AppStatus.IDLE);
            stopCameraStream();
          },
          onStatusUpdate: (msg) => setLoadingMsg(msg),
          onSpeaking: (speaking) => setIsSpeaking(speaking),
        },
        'EZUMI',
        () => (videoRef.current && cameraActive ? videoRef.current : null),
        turns
      );
      setStatus(AppStatus.LISTENING);
    } catch (e) {
      setStatus(AppStatus.ERROR);
      stopCameraStream();
    }
  };

  const endVideoCallStage = async () => {
    await voiceServiceRef.current.stop();
    stopCameraStream();
    setStatus(AppStatus.IDLE);
    setActiveView('chat');
    if (config.wakeWordEnabled) {
      voiceController.startWakeWord();
    }
  };

  const latestTurn = turns[turns.length - 1];

  return (
    <div className="flex h-screen w-screen bg-[#000000] text-white overflow-hidden select-none font-['Quicksand',sans-serif]">
      
      {/* 1. COLLAPSIBLE CHAT SIDEBAR */}
      <ChatSidebar
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onNewChat={() => {
          setTurns([]);
          localStorage.removeItem(STORAGE_KEY);
        }}
        turns={turns}
        onOpenNotes={() => setIsNotesOpen(true)}
        onOpenTasks={() => setIsTasksOpen(true)}
        onOpenResearch={() => {
          setResearchMode('search');
          setIsResearchOpen(true);
        }}
        onOpenDevice={() => setIsDeviceOpen(true)}
        onOpenVideoCall={launchVideoCallStage}
        onOpenSettings={() => setIsSettingsOpen(true)}
        wakeWordEnabled={config.wakeWordEnabled}
        onToggleWakeWord={() => handleUpdateConfig({ wakeWordEnabled: !config.wakeWordEnabled })}
        user={user}
        onLogin={signInWithGoogle}
        onLogout={logout}
        dbSyncStatus={dbSyncStatus}
      />

      {/* 2. MAIN APPLICATION CONTENT AREA */}
      <div className="flex-1 flex flex-col h-full bg-[#000000] relative overflow-hidden">
        
        {/* A. HEADER BAR */}
        <header className="h-14 border-b border-[#1A1A1A] px-4 flex items-center justify-between bg-[#000000] z-20 shrink-0">
          
          {/* Left: Sidebar Toggle & EZUMI Title */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              aria-label="Toggle sidebar"
              className="p-1.5 rounded-lg text-[#A0A0A0] hover:text-white hover:bg-[#141414] transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2">
              <span className="font-bold text-base tracking-tight text-white">EZUMI</span>
              <span className="text-[10px] font-semibold text-[#808080] border border-[#262626] bg-[#0E0E0E] px-2 py-0.5 rounded-full hidden sm:inline-block">
                gemini-3.8-flash
              </span>
            </div>
          </div>

          {/* Center: Assistant Visual Status Badge */}
          <div className="flex items-center gap-2">
            <div
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border transition-all ${
                wakeWordTriggered
                  ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300 shadow-sm animate-pulse'
                  : assistantState === 'listening'
                  ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300'
                  : assistantState === 'speaking'
                  ? 'bg-pink-950/80 border-pink-500 text-pink-300'
                  : assistantState === 'processing'
                  ? 'bg-purple-950/80 border-purple-500 text-purple-300'
                  : 'bg-[#121212] border-[#222222] text-[#808080]'
              }`}
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  wakeWordTriggered
                    ? 'bg-emerald-400 animate-ping'
                    : assistantState === 'listening'
                    ? 'bg-cyan-400 animate-pulse'
                    : assistantState === 'speaking'
                    ? 'bg-pink-400 animate-pulse'
                    : assistantState === 'processing'
                    ? 'bg-purple-400 animate-spin'
                    : 'bg-[#555555]'
                }`}
              />
              <span className="uppercase text-[10px] tracking-wider">
                {wakeWordTriggered
                  ? 'Wake Word Heard'
                  : assistantState === 'listening'
                  ? 'Listening'
                  : assistantState === 'speaking'
                  ? 'Speaking'
                  : assistantState === 'processing'
                  ? 'Thinking'
                  : 'Standby'}
              </span>
            </div>
          </div>

          {/* Right: Quick Actions (Face-to-face video toggle, new conversation, settings) */}
          <div className="flex items-center gap-1 sm:gap-2">
            {activeView === 'chat' ? (
              <button
                onClick={launchVideoCallStage}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-700/60 text-emerald-300 text-xs font-semibold transition-all active:scale-95"
                title="Face-to-Face Video & Vision Call"
              >
                <Video className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Video Call</span>
              </button>
            ) : (
              <button
                onClick={endVideoCallStage}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-950/60 hover:bg-red-900/60 border border-red-700/60 text-red-300 text-xs font-semibold transition-all active:scale-95"
              >
                <span>End Call</span>
              </button>
            )}

            <button
              onClick={() => {
                setTurns([]);
                localStorage.removeItem(STORAGE_KEY);
              }}
              aria-label="New chat"
              className="p-2 rounded-lg text-[#A0A0A0] hover:text-white hover:bg-[#141414] transition-colors"
              title="New Conversation"
            >
              <Plus className="w-4 h-4" />
            </button>

            <button
              onClick={() => setIsSettingsOpen(true)}
              aria-label="Settings"
              className="p-2 rounded-lg text-[#A0A0A0] hover:text-white hover:bg-[#141414] transition-colors"
              title="Settings & Privacy"
            >
              <Sliders className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* B. MAIN VIEWPORT */}
        {activeView === 'video_call' ? (
          /* FULL FACE-TO-FACE VISION CALL STAGE */
          <div className="flex-1 w-full h-full relative overflow-hidden bg-black flex flex-col">
            <VideoCallStage
              videoRef={videoRef}
              cameraActive={cameraActive}
              cameraLoading={cameraLoading}
              cameraError={cameraError}
              cameraFacingMode={cameraFacingMode}
              micMuted={micMuted}
              isVaniSpeaking={isSpeaking}
              callDuration={callDuration}
              mood={mood}
              hydration={hydration}
              hunger={hunger}
              latestTurn={latestTurn}
              aiName="EZUMI"
              isScreenSharing={isScreenSharing}
              onToggleCamera={toggleCamera}
              onToggleFacingMode={toggleFacingMode}
              onToggleMic={toggleMic}
              onToggleScreenShare={toggleScreenShare}
              onEndCall={endVideoCallStage}
              onCareAction={() => {}}
            />
          </div>
        ) : (
          /* CHATGPT-STYLE CHAT VIEW WITH VOICE ASSISTANT AREA */
          <div className="flex-1 flex flex-col h-full overflow-hidden">
            
            {/* Error Notification Banner */}
            {errorMsg && (
              <div className="mx-4 mt-2 px-3 py-2 rounded-xl bg-red-950/70 border border-red-800 text-red-300 text-xs flex items-center justify-between animate-in fade-in">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                  <span>{errorMsg}</span>
                </div>
                <button
                  onClick={() => setErrorMsg(null)}
                  className="p-1 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Top Voice Assistant Orb Area */}
            <div className="border-b border-[#141414] bg-[#050505]">
              <VoiceVisualizer
                state={assistantState}
                wakeWordEnabled={config.wakeWordEnabled}
                micPermission={micPermission}
                isListening={assistantState === 'listening'}
                isSpeaking={isSpeaking}
                lastTranscript={lastTranscript}
                onToggleListening={toggleManualDictation}
                onStopSpeaking={stopSpeaking}
                wakeWordTriggered={wakeWordTriggered}
              />
            </div>

            {/* Scrollable Chat Area */}
            <div
              ref={chatScrollRef}
              className="flex-1 overflow-y-auto overflow-x-hidden flex flex-col"
            >
              <ChatMessageView
                turns={turns}
                isProcessing={isProcessing}
                onSpeak={speakText}
                onSelectPrompt={(p) => handleSendMessage(p)}
                onOpenVideoCall={launchVideoCallStage}
                onOpenResearch={() => {
                  setResearchMode('search');
                  setIsResearchOpen(true);
                }}
                onOpenTasks={() => setIsTasksOpen(true)}
                onOpenNotes={() => setIsNotesOpen(true)}
              />
            </div>

            {/* Bottom Message Input Area */}
            <ChatInputArea
              input={inputText}
              setInput={setInputText}
              onSend={() => handleSendMessage()}
              isProcessing={isProcessing}
              isListening={isDictating}
              onToggleMic={toggleManualDictation}
              isSpeaking={isSpeaking}
              onStopSpeaking={stopSpeaking}
              wakeWordEnabled={config.wakeWordEnabled}
            />
          </div>
        )}

      </div>

      {/* 3. SETTINGS & PREFERENCES MODAL */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        config={config}
        onUpdateConfig={handleUpdateConfig}
        memoriesCount={turns.length}
        onClearMemories={clearAllMemories}
        onExportMemories={exportMemories}
        dbSyncStatus={dbSyncStatus}
        userEmail={user?.email}
        onTestVoice={() => speakText("Hello, this is EZUMI speaking. Voice synthesis is working smoothly.")}
        onTestMic={toggleManualDictation}
        micPermission={micPermission}
      />

      {/* 4. SUBSYSTEM MODALS (PRESERVED & FULLY FUNCTIONAL) */}
      <SmartNotepadModal
        isOpen={isNotesOpen}
        onClose={() => setIsNotesOpen(false)}
        token={token}
        onSpeakText={speakText}
      />

      <AutonomousTaskModal
        isOpen={isTasksOpen}
        onClose={() => setIsTasksOpen(false)}
        token={token}
      />

      <WebResearchNewsModal
        isOpen={isResearchOpen}
        onClose={() => setIsResearchOpen(false)}
        token={token}
        initialQuery={initialResearchQuery}
        initialMode={researchMode}
        onSpeakText={speakText}
      />

      <DeviceCommModal
        isOpen={isDeviceOpen}
        onClose={() => setIsDeviceOpen(false)}
        token={token}
        onStartScreenShare={toggleScreenShare}
        isScreenSharing={isScreenSharing}
      />
    </div>
  );
};

export default App;
